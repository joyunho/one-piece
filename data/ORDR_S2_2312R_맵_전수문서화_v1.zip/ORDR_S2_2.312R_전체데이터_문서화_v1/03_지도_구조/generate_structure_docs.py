#!/usr/bin/env python3
"""Generate exhaustive, read-only structure documentation for a WC3 map.

All generated artifacts are written under the directory containing this script.
The original map and the shared extracted directory are never modified.
"""

from __future__ import annotations

import configparser
import csv
import gzip
import hashlib
import importlib.util
import json
import math
import re
import shutil
import struct
import sys
from collections import Counter
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


HERE = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def dump_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def open_csv(path: Path):
    return path.open("w", newline="", encoding="utf-8-sig")


def open_csv_gzip(path: Path):
    return gzip.open(path, "wt", newline="", encoding="utf-8-sig", compresslevel=9)


def fourcc(raw: bytes) -> str:
    return raw.decode("ascii", errors="backslashreplace")


class Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def need(self, count: int) -> None:
        if count < 0 or self.pos + count > len(self.data):
            raise ValueError(f"truncated at {self.pos}: need {count}, total {len(self.data)}")

    def take(self, count: int) -> bytes:
        self.need(count)
        result = self.data[self.pos:self.pos + count]
        self.pos += count
        return result

    def unpack(self, fmt: str):
        count = struct.calcsize(fmt)
        self.need(count)
        values = struct.unpack_from(fmt, self.data, self.pos)
        self.pos += count
        return values[0] if len(values) == 1 else values

    def i32(self): return self.unpack("<i")
    def u32(self): return self.unpack("<I")
    def i16(self): return self.unpack("<h")
    def u16(self): return self.unpack("<H")
    def u8(self): return self.unpack("<B")
    def f32(self): return self.unpack("<f")


def load_base_parser():
    parser_path = HERE.parents[1] / "structure_agent" / "parse_map_structure.py"
    spec = importlib.util.spec_from_file_location("ord_structure_parser", parser_path)
    if not spec or not spec.loader:
        raise RuntimeError(f"cannot import {parser_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_wts(extracted: Path) -> dict[int, str]:
    text = (extracted / "war3map.wts").read_bytes().decode("utf-8-sig", errors="replace")
    values: dict[int, str] = {}
    pattern = re.compile(r"(?m)^STRING\s+(\d+)\s*\r?\n(?:[^\r\n]*\r?\n)*?\{\r?\n(.*?)\r?\n\}", re.S)
    for match in pattern.finditer(text):
        values[int(match.group(1))] = match.group(2)
    return values


def resolve_trigstr(value: str, wts: dict[int, str]) -> str:
    match = re.fullmatch(r"TRIGSTR_(\d+)", value)
    return wts.get(int(match.group(1)), value) if match else value


def build_mpq_manifest(lookup_path: Path) -> dict:
    lookup = json.loads(lookup_path.read_text(encoding="utf-8"))
    descriptions = {
        "war3map.j": "실행용 컴파일 JASS",
        "war3map.lua": "Lua 실행 스크립트 대안",
        "war3map.w3i": "지도 메타·플레이어·force",
        "war3map.wts": "TRIGSTR 문자열 테이블",
        "war3map.wtg": "GUI 트리거 구조 원본",
        "war3map.wct": "GUI 사용자 스크립트 원본",
        "war3mapUnits.doo": "사전 배치 유닛·아이템",
        "war3map.doo": "도오다드·파괴물 배치",
        "war3map.w3e": "지형 꼭짓점",
        "war3map.wpm": "pathing 격자",
        "war3map.shd": "정적 지형 그림자",
        "war3map.mmp": "미니맵 아이콘",
        "war3map.imp": "임포트 이름 목록",
        "(listfile)": "MPQ 전체 파일명 목록",
        "(attributes)": "MPQ 파일 속성(선택)",
        "(signature)": "MPQ 서명(선택)",
        "war3map.w3r": "에디터 region 원본",
        "war3map.w3c": "에디터 camera 원본",
        "war3map.w3s": "에디터 sound 원본",
        "war3map.w3o": "통합 object data 대안",
        "LoadingScreen.mdx": "W3I가 직접 참조하는 로딩 모델",
    }
    output = HERE / "mpq_standard_file_manifest.csv"
    fields = [
        "path", "description", "exists_by_exact_lookup", "size_bytes", "sha256",
        "extraction_status", "extracted_relative_path", "extracted_size_bytes",
        "extracted_sha256", "extracted_matches_lookup", "lookup_error",
        "confidence_note"
    ]
    with open_csv(output) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in lookup["standardPathRows"]:
            name = row["path"]
            description = descriptions.get(name, descriptions.get(name.replace("Scripts\\", ""), "알려진 표준·대체 경로"))
            confidence = (
                "정확한 파일명으로 MPQ 해시 조회 성공"
                if row["existsByExactLookup"]
                else "이 정확한 경로는 조회 실패; listfile 부재로 이름이 다른 파일까지 부재라고 단정할 수 없음"
            )
            writer.writerow({
                "path": name,
                "description": description,
                "exists_by_exact_lookup": row["existsByExactLookup"],
                "size_bytes": "" if row["size"] is None else row["size"],
                "sha256": row["sha256"],
                "extraction_status": row["extractionStatus"],
                "extracted_relative_path": row["extractedRelativePath"],
                "extracted_size_bytes": "" if row["extractedSize"] is None else row["extractedSize"],
                "extracted_sha256": row["extractedSha256"],
                "extracted_matches_lookup": "" if row["extractedMatchesLookup"] is None else row["extractedMatchesLookup"],
                "lookup_error": row["lookupError"],
                "confidence_note": confidence,
            })
    return lookup


def build_w3i(base, source: Path, extracted: Path, wts: dict[int, str]) -> dict:
    w3i = base.parse_w3i(extracted / "war3map.w3i", wts)
    for force in w3i["forces"]:
        mask = int(force["playerMask"])
        force["setPlayerBits0To31"] = [bit for bit in range(32) if mask & (1 << bit)]
        force["declaredPlayerBits"] = [bit for bit in range(len(w3i["players"])) if mask & (1 << bit)]
        force["bitsOutsideDeclaredPlayers"] = [bit for bit in range(len(w3i["players"]), 32) if mask & (1 << bit)]
        force["playerMaskHex"] = f"0x{mask:08X}"
    dump_json(HERE / "w3i_full.json", w3i)

    player_fields = [
        "record_index", "player_number", "type_code", "race_code", "fixed_start",
        "name_raw", "name_resolved", "start_x_world", "start_y_world",
        "ally_low_priority_mask", "ally_low_priority_hex", "ally_high_priority_mask",
        "ally_high_priority_hex", "confidence_note"
    ]
    with open_csv(HERE / "w3i_players.csv") as handle:
        writer = csv.DictWriter(handle, fieldnames=player_fields)
        writer.writeheader()
        for index, player in enumerate(w3i["players"]):
            writer.writerow({
                "record_index": index,
                "player_number": player["number"],
                "type_code": player["type"],
                "race_code": player["race"],
                "fixed_start": player["fixedStart"],
                "name_raw": player["nameRaw"],
                "name_resolved": player["name"],
                "start_x_world": player["startX"],
                "start_y_world": player["startY"],
                "ally_low_priority_mask": player["allyLowPriority"],
                "ally_low_priority_hex": f"0x{player['allyLowPriority']:08X}",
                "ally_high_priority_mask": player["allyHighPriority"],
                "ally_high_priority_hex": f"0x{player['allyHighPriority']:08X}",
                "confidence_note": "W3I 원시 레코드 직접 파싱; type/race 숫자는 포맷 코드",
            })

    force_fields = [
        "force_index", "flags", "flags_hex", "player_mask", "player_mask_hex",
        "name_raw", "name_resolved", "all_set_bits_0_to_31", "declared_player_bits",
        "bits_outside_declared_players", "confidence_note"
    ]
    with open_csv(HERE / "w3i_forces.csv") as handle:
        writer = csv.DictWriter(handle, fieldnames=force_fields)
        writer.writeheader()
        for index, force in enumerate(w3i["forces"]):
            writer.writerow({
                "force_index": index,
                "flags": force["flags"],
                "flags_hex": f"0x{force['flags']:08X}",
                "player_mask": force["playerMask"],
                "player_mask_hex": force["playerMaskHex"],
                "name_raw": force["nameRaw"],
                "name_resolved": force["name"],
                "all_set_bits_0_to_31": ",".join(map(str, force["setPlayerBits0To31"])),
                "declared_player_bits": ",".join(map(str, force["declaredPlayerBits"])),
                "bits_outside_declared_players": ",".join(map(str, force["bitsOutsideDeclaredPlayers"])),
                "confidence_note": "mask의 선언 player 범위 밖 비트는 별도 분리; 실효 슬롯으로 계산하지 않음",
            })
    return w3i


def gradient_color(value: float) -> tuple[int, int, int]:
    value = min(1.0, max(0.0, value))
    stops = [(30, 30, 90), (35, 125, 165), (60, 180, 110), (240, 210, 70), (245, 245, 225)]
    p = value * (len(stops) - 1)
    index = min(len(stops) - 2, int(p))
    fraction = p - index
    a, b = stops[index], stops[index + 1]
    return tuple(round(a[channel] * (1 - fraction) + b[channel] * fraction) for channel in range(3))


def font(size: int):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def build_map_canvas(grid: Image.Image, title: str, x_extent, y_extent, legend_lines: list[tuple[str, tuple[int, int, int] | None]]) -> Image.Image:
    plot_size = 768
    left, top = 72, 72
    canvas = Image.new("RGB", (1160, 900), (20, 23, 30))
    draw = ImageDraw.Draw(canvas)
    canvas.paste(grid.resize((plot_size, plot_size), Image.Resampling.NEAREST), (left, top))
    draw.rectangle((left, top, left + plot_size - 1, top + plot_size - 1), outline=(220, 225, 235), width=2)
    draw.text((left, 20), title, fill=(245, 245, 245), font=font(24))
    draw.text((left, top + plot_size + 12), f"X: {x_extent[0]:g} -> {x_extent[1]:g} world units", fill=(220, 225, 235), font=font(15))
    draw.text((left + 410, top + plot_size + 12), f"Y: {y_extent[0]:g} -> {y_extent[1]:g} (up)", fill=(220, 225, 235), font=font(15))
    legend_x, legend_y = 875, 78
    for label, color in legend_lines:
        if color is not None:
            draw.rectangle((legend_x, legend_y + 2, legend_x + 16, legend_y + 18), fill=color, outline=(240, 240, 240))
            text_x = legend_x + 24
        else:
            text_x = legend_x
        draw.text((text_x, legend_y), label, fill=(235, 235, 235), font=font(14))
        legend_y += 27
    return canvas


def build_w3e(extracted: Path) -> dict:
    data = (extracted / "war3map.w3e").read_bytes()
    r = Reader(data)
    magic, version, tileset, custom = fourcc(r.take(4)), r.i32(), chr(r.u8()), r.i32()
    ground_ids = [fourcc(r.take(4)) for _ in range(r.i32())]
    cliff_ids = [fourcc(r.take(4)) for _ in range(r.i32())]
    width, height, offset_x, offset_y = r.i32(), r.i32(), r.f32(), r.f32()
    vertices = []
    ground_counts, cliff_counts, layer_counts = Counter(), Counter(), Counter()
    flag_counts = Counter()
    height_values = []
    water_height_values = []
    normalized_height_values = []
    csv_fields = [
        "index", "grid_x", "grid_y", "world_x", "world_y", "ground_height_raw_i16",
        "ground_height_normalized", "ground_height_world_z", "water_and_edge_raw_u16",
        "water_height_raw_14bit", "water_height_normalized", "water_height_world_z",
        "map_edge_flag", "texture_flags_raw_u8", "ramp_flag", "blight_flag", "water_flag",
        "boundary_flag", "ground_texture_index", "ground_texture_fourcc", "variation_raw_u8",
        "cliff_variation", "ground_variation", "cliff_layer_raw_u8", "cliff_texture_index",
        "cliff_texture_fourcc", "layer_height", "confidence_note"
    ]
    with open_csv_gzip(HERE / "w3e_vertices.csv.gz") as handle:
        writer = csv.DictWriter(handle, fieldnames=csv_fields)
        writer.writeheader()
        for index in range(width * height):
            x, y = index % width, index // width
            ground_raw, water_edge = r.i16(), r.u16()
            texture_flags, variation, cliff_layer = r.u8(), r.u8(), r.u8()
            ground_normalized = (ground_raw - 8192) / 512.0
            water_raw = water_edge & 0x3FFF
            water_normalized = (water_raw - 8192) / 512.0
            ground_texture = texture_flags & 0x0F
            cliff_texture = (cliff_layer >> 4) & 0x0F
            layer_height = cliff_layer & 0x0F
            row = {
                "index": index, "grid_x": x, "grid_y": y,
                "world_x": offset_x + x * 128.0, "world_y": offset_y + y * 128.0,
                "ground_height_raw_i16": ground_raw,
                "ground_height_normalized": ground_normalized,
                "ground_height_world_z": ground_normalized * 128.0,
                "water_and_edge_raw_u16": water_edge,
                "water_height_raw_14bit": water_raw,
                "water_height_normalized": water_normalized,
                "water_height_world_z": water_normalized * 128.0,
                "map_edge_flag": int(bool(water_edge & 0x4000)),
                "texture_flags_raw_u8": texture_flags,
                "ramp_flag": int(bool(texture_flags & 0x10)),
                "blight_flag": int(bool(texture_flags & 0x20)),
                "water_flag": int(bool(texture_flags & 0x40)),
                "boundary_flag": int(bool(texture_flags & 0x80)),
                "ground_texture_index": ground_texture,
                "ground_texture_fourcc": ground_ids[ground_texture] if ground_texture < len(ground_ids) else "",
                "variation_raw_u8": variation,
                "cliff_variation": (variation >> 5) & 0x07,
                "ground_variation": variation & 0x1F,
                "cliff_layer_raw_u8": cliff_layer,
                "cliff_texture_index": cliff_texture,
                "cliff_texture_fourcc": cliff_ids[cliff_texture] if cliff_texture < len(cliff_ids) else "",
                "layer_height": layer_height,
                "confidence_note": "W3E v11 직접 파싱; grid는 row-major, y가 증가할수록 북쪽",
            }
            writer.writerow(row)
            vertices.append(row)
            height_values.append(row["ground_height_world_z"])
            normalized_height_values.append(row["ground_height_normalized"])
            water_height_values.append(row["water_height_world_z"])
            ground_counts[ground_texture] += 1
            cliff_counts[cliff_texture] += 1
            layer_counts[layer_height] += 1
            for key in ("map_edge_flag", "ramp_flag", "blight_flag", "water_flag", "boundary_flag"):
                flag_counts[key] += row[key]
    if r.pos != len(data):
        raise ValueError(f"W3E trailing bytes: {len(data) - r.pos}")
    summary = {
        "magic": magic, "version": version, "tileset": tileset, "customTilesets": bool(custom),
        "groundTileIds": ground_ids, "cliffTileIds": cliff_ids,
        "vertexWidth": width, "vertexHeight": height, "vertexRows": width * height,
        "cellWidth": width - 1, "cellHeight": height - 1,
        "cellSizeWorldUnits": 128, "worldOffsetX": offset_x, "worldOffsetY": offset_y,
        "worldExtentX": [offset_x, offset_x + (width - 1) * 128],
        "worldExtentY": [offset_y, offset_y + (height - 1) * 128],
        "groundHeightWorldMinMax": [min(height_values), max(height_values)],
        "groundHeightNormalizedMinMax": [min(normalized_height_values), max(normalized_height_values)],
        "waterHeightWorldMinMax": [min(water_height_values), max(water_height_values)],
        "groundTextureCounts": [
            {"index": i, "fourcc": ground_ids[i], "vertices": ground_counts.get(i, 0)} for i in range(len(ground_ids))
        ],
        "cliffTextureCounts": [
            {"index": i, "fourcc": cliff_ids[i], "vertices": cliff_counts.get(i, 0)} for i in range(len(cliff_ids))
        ],
        "layerHeightCounts": {str(key): value for key, value in sorted(layer_counts.items())},
        "flagCounts": dict(flag_counts), "sourceBytes": len(data), "sourceSha256": hashlib.sha256(data).hexdigest(),
        "csvRowsExcludingHeader": width * height,
    }
    dump_json(HERE / "w3e_summary.json", summary)

    min_height, max_height = min(height_values), max(height_values)
    height_pixels = []
    tile_palette = [
        (231, 76, 60), (52, 152, 219), (46, 204, 113), (241, 196, 15),
        (155, 89, 182), (230, 126, 34), (26, 188, 156), (149, 165, 166),
        (192, 57, 43), (41, 128, 185), (39, 174, 96), (243, 156, 18),
        (142, 68, 173), (211, 84, 0), (22, 160, 133), (127, 140, 141),
    ]
    tile_pixels = []
    for visual_y in reversed(range(height)):
        for x in range(width):
            row = vertices[visual_y * width + x]
            ratio = 0 if max_height == min_height else (row["ground_height_world_z"] - min_height) / (max_height - min_height)
            height_pixels.append(gradient_color(ratio))
            tile_pixels.append(tile_palette[row["ground_texture_index"] % len(tile_palette)])
    height_image = Image.new("RGB", (width, height)); height_image.putdata(height_pixels)
    height_legend = [
        (f"Ground Z min: {min_height:g}", gradient_color(0)),
        (f"Ground Z mid: {(min_height + max_height) / 2:g}", gradient_color(.5)),
        (f"Ground Z max: {max_height:g}", gradient_color(1)),
        ("Nearest-neighbor display", None),
        ("Source: all 193x193 vertices", None),
    ]
    build_map_canvas(height_image, "W3E ground height map (visual aid)", summary["worldExtentX"], summary["worldExtentY"], height_legend).save(HERE / "w3e_heightmap.png")
    tile_image = Image.new("RGB", (width, height)); tile_image.putdata(tile_pixels)
    tile_legend = [(f"{i}: {tile_id} ({ground_counts.get(i, 0)})", tile_palette[i]) for i, tile_id in enumerate(ground_ids)]
    build_map_canvas(tile_image, "W3E ground tile index map (visual aid)", summary["worldExtentX"], summary["worldExtentY"], tile_legend).save(HERE / "w3e_ground_tile_index.png")
    return summary


def build_wpm(extracted: Path, terrain: dict) -> dict:
    data = (extracted / "war3map.wpm").read_bytes()
    r = Reader(data)
    magic, version, width, height = fourcc(r.take(4)), r.i32(), r.i32(), r.i32()
    raw = r.take(width * height)
    if r.pos != len(data):
        raise ValueError(f"WPM trailing bytes: {len(data) - r.pos}")
    (HERE / "wpm_pathing_raw.bin").write_bytes(raw)
    counts = Counter(raw)
    bit_counts = {f"0x{bit_value:02X}": sum(count for value, count in counts.items() if value & bit_value) for bit_value in (1, 2, 4, 8, 16, 32, 64, 128)}
    fields = [
        "index", "grid_x", "grid_y", "world_center_x", "world_center_y", "raw_u8", "raw_hex",
        "bit_01", "bit_02", "bit_04", "bit_08", "bit_10", "bit_20", "bit_40", "bit_80",
        "confidence_note"
    ]
    with open_csv_gzip(HERE / "wpm_pathing.csv.gz") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for index, value in enumerate(raw):
            x, y = index % width, index // width
            writer.writerow({
                "index": index, "grid_x": x, "grid_y": y,
                "world_center_x": terrain["worldOffsetX"] + x * 32 + 16,
                "world_center_y": terrain["worldOffsetY"] + y * 32 + 16,
                "raw_u8": value, "raw_hex": f"0x{value:02X}",
                "bit_01": int(bool(value & 0x01)), "bit_02": int(bool(value & 0x02)),
                "bit_04": int(bool(value & 0x04)), "bit_08": int(bool(value & 0x08)),
                "bit_10": int(bool(value & 0x10)), "bit_20": int(bool(value & 0x20)),
                "bit_40": int(bool(value & 0x40)), "bit_80": int(bool(value & 0x80)),
                "confidence_note": "raw bit만 확정; 의미 명칭은 엔진 버전별 정의 검증 전 부여하지 않음",
            })
    summary = {
        "magic": magic, "version": version, "width": width, "height": height,
        "cells": width * height, "rowMajor": True, "gridYIncreasesNorth": True,
        "cellSizeWorldUnits": 32, "rawPayloadBytes": len(raw),
        "rawValueCounts": {f"0x{key:02X}": value for key, value in sorted(counts.items())},
        "bitSetCounts": bit_counts, "sourceBytes": len(data), "sourceSha256": hashlib.sha256(data).hexdigest(),
        "rawPayloadSha256": hashlib.sha256(raw).hexdigest(), "csvRowsExcludingHeader": width * height,
        "interpretationBoundary": "값과 비트는 확정. 각 비트의 walk/fly/build 의미 명칭은 별도 엔진 사양 검증 없이는 추정하지 않음.",
    }
    dump_json(HERE / "wpm_summary.json", summary)

    colors = {
        0x08: (63, 81, 181), 0x0A: (33, 150, 243), 0x40: (0, 188, 212),
        0x48: (76, 175, 80), 0xCA: (255, 193, 7), 0xCE: (244, 67, 54),
    }
    pixels = []
    for visual_y in reversed(range(height)):
        for x in range(width):
            value = raw[visual_y * width + x]
            pixels.append(colors.get(value, (220, 220, 220)))
    image = Image.new("RGB", (width, height)); image.putdata(pixels)
    legend = [(f"0x{value:02X}: {counts[value]} cells", color) for value, color in colors.items()]
    legend.extend([("Discrete raw byte colors", None), ("No semantic bit labels inferred", None)])
    build_map_canvas(image, "WPM raw pathing values (visual aid)", terrain["worldExtentX"], terrain["worldExtentY"], legend).save(HERE / "wpm_raw_values.png")
    return summary


def build_doo(extracted: Path, terrain: dict) -> dict:
    data = (extracted / "war3map.doo").read_bytes()
    r = Reader(data)
    magic, version, subversion, count = fourcc(r.take(4)), r.i32(), r.i32(), r.i32()
    rows = []
    rawcodes, variations, flags_counts, life_counts = Counter(), Counter(), Counter(), Counter()
    fields = [
        "index", "rawcode", "variation", "position_x", "position_y", "position_z",
        "angle_radians", "angle_degrees", "scale_x", "scale_y", "scale_z", "flags_u8",
        "life_percent_u8", "item_table_pointer", "item_set_count", "item_sets_json",
        "editor_creation_number", "confidence_note"
    ]
    with open_csv(HERE / "doo_placements.csv") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for index in range(count):
            rawcode, variation = fourcc(r.take(4)), r.i32()
            x, y, z, angle = r.f32(), r.f32(), r.f32(), r.f32()
            scale_x, scale_y, scale_z = r.f32(), r.f32(), r.f32()
            flags, life, item_table, item_set_count = r.u8(), r.u8(), r.i32(), r.i32()
            item_sets = []
            for _ in range(item_set_count):
                items = []
                for _ in range(r.i32()):
                    items.append({"rawcode": fourcc(r.take(4)), "chance": r.i32()})
                item_sets.append(items)
            editor_id = r.i32()
            row = {
                "index": index, "rawcode": rawcode, "variation": variation,
                "position_x": x, "position_y": y, "position_z": z,
                "angle_radians": angle, "angle_degrees": angle * 180 / math.pi,
                "scale_x": scale_x, "scale_y": scale_y, "scale_z": scale_z,
                "flags_u8": flags, "life_percent_u8": life, "item_table_pointer": item_table,
                "item_set_count": item_set_count,
                "item_sets_json": json.dumps(item_sets, ensure_ascii=False, separators=(",", ":")),
                "editor_creation_number": editor_id,
                "confidence_note": "DOO v8 직접 파싱; position/scale/angle은 저장 원시값",
            }
            writer.writerow(row); rows.append(row)
            rawcodes[rawcode] += 1; variations[variation] += 1; flags_counts[flags] += 1; life_counts[life] += 1
    special_version, special_count = r.i32(), r.i32()
    specials = []
    for index in range(special_count):
        specials.append({"index": index, "rawcode": fourcc(r.take(4)), "x": r.i32(), "y": r.i32()})
    if r.pos != len(data):
        raise ValueError(f"DOO trailing bytes: {len(data) - r.pos}")
    summary = {
        "magic": magic, "version": version, "subversion": subversion,
        "doodadRows": count, "uniqueRawcodes": len(rawcodes),
        "rawcodeCounts": dict(rawcodes.most_common()),
        "variationCounts": {str(k): v for k, v in sorted(variations.items())},
        "flagsCounts": {str(k): v for k, v in sorted(flags_counts.items())},
        "lifePercentCounts": {str(k): v for k, v in sorted(life_counts.items())},
        "itemTableMinusOneRows": sum(1 for row in rows if row["item_table_pointer"] == -1),
        "rowsWithEmbeddedItemSets": sum(1 for row in rows if row["item_set_count"]),
        "positionBounds": {
            axis: [min(row[f"position_{axis}"] for row in rows), max(row[f"position_{axis}"] for row in rows)]
            for axis in ("x", "y", "z")
        },
        "specialDoodadVersion": special_version, "specialDoodadCount": special_count,
        "specialDoodads": specials, "sourceBytes": len(data), "sourceSha256": hashlib.sha256(data).hexdigest(),
        "csvRowsExcludingHeader": count,
    }
    dump_json(HERE / "doo_summary.json", summary)

    top_codes = [name for name, _ in rawcodes.most_common(8)]
    palette = [(231, 76, 60), (52, 152, 219), (46, 204, 113), (241, 196, 15), (155, 89, 182), (230, 126, 34), (26, 188, 156), (236, 240, 241)]
    color_by_code = {code: palette[index] for index, code in enumerate(top_codes)}
    plot_size, left, top = 768, 72, 72
    canvas = Image.new("RGB", (1160, 900), (20, 23, 30)); draw = ImageDraw.Draw(canvas)
    draw.rectangle((left, top, left + plot_size, top + plot_size), fill=(34, 38, 47), outline=(220, 225, 235), width=2)
    min_x, max_x = terrain["worldExtentX"]; min_y, max_y = terrain["worldExtentY"]
    for row in rows:
        px = left + int((row["position_x"] - min_x) / (max_x - min_x) * (plot_size - 1))
        py = top + plot_size - 1 - int((row["position_y"] - min_y) / (max_y - min_y) * (plot_size - 1))
        color = color_by_code.get(row["rawcode"], (130, 135, 145))
        draw.ellipse((px - 2, py - 2, px + 2, py + 2), fill=color)
    draw.text((left, 20), "DOO doodad placement scatter (visual aid)", fill=(245, 245, 245), font=font(24))
    draw.text((left, top + plot_size + 12), f"X: {min_x:g} -> {max_x:g} world units", fill=(220, 225, 235), font=font(15))
    draw.text((left + 410, top + plot_size + 12), f"Y: {min_y:g} -> {max_y:g} (up)", fill=(220, 225, 235), font=font(15))
    legend_y = 78
    for code in top_codes:
        color = color_by_code[code]
        draw.rectangle((875, legend_y + 2, 891, legend_y + 18), fill=color)
        draw.text((899, legend_y), f"{code}: {rawcodes[code]}", fill=(235, 235, 235), font=font(14))
        legend_y += 27
    draw.rectangle((875, legend_y + 2, 891, legend_y + 18), fill=(130, 135, 145))
    draw.text((899, legend_y), f"other: {count - sum(rawcodes[c] for c in top_codes)}", fill=(235, 235, 235), font=font(14))
    draw.text((875, legend_y + 40), "Each dot is one DOO row", fill=(235, 235, 235), font=font(14))
    canvas.save(HERE / "doo_scatter.png")
    return summary


def parse_ini_file(path: Path) -> dict:
    parser = configparser.ConfigParser(strict=False, interpolation=None)
    parser.optionxform = str
    parser.read_string(path.read_text(encoding="utf-8-sig", errors="replace"))
    return {section: dict(parser.items(section)) for section in parser.sections()}


def build_auxiliary(base, extracted: Path, wts: dict[int, str]) -> dict:
    mmp = base.parse_mmp(extracted / "war3map.mmp")
    dump_json(HERE / "mmp_full.json", mmp)
    with open_csv(HERE / "mmp_icons.csv") as handle:
        fields = ["index", "type_code", "map_pixel_x", "map_pixel_y", "color_byte_0", "color_byte_1", "color_byte_2", "color_byte_3", "confidence_note"]
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader()
        for index, icon in enumerate(mmp["icons"]):
            color = icon["rawColorBytes"]
            writer.writerow({
                "index": index, "type_code": icon["type"], "map_pixel_x": icon["x"], "map_pixel_y": icon["y"],
                "color_byte_0": color[0], "color_byte_1": color[1], "color_byte_2": color[2], "color_byte_3": color[3],
                "confidence_note": "좌표·색상 바이트는 확정; 채널 의미는 원시 순서로 보존",
            })

    copied = []
    for name in ("war3mapMap.blp", "war3mapPreview.tga", "war3mapSkin.txt", "war3mapMisc.txt", "war3mapExtra.txt", "war3map.shd"):
        source, target = extracted / name, HERE / name
        shutil.copyfile(source, target)
        copied.append({"file": name, "size": target.stat().st_size, "sha256": sha256(target), "matchesSource": sha256(target) == sha256(source)})
    preview = Image.open(HERE / "war3mapPreview.tga")
    preview.save(HERE / "war3mapPreview.png")
    copied.append({"file": "war3mapPreview.png", "size": (HERE / "war3mapPreview.png").stat().st_size, "sha256": sha256(HERE / "war3mapPreview.png"), "matchesSource": "derived PNG"})

    skin_text = (extracted / "war3mapSkin.txt").read_text(encoding="utf-8-sig", errors="replace")
    resolved_skin = re.sub(r"TRIGSTR_(\d+)", lambda m: wts.get(int(m.group(1)), m.group(0)).replace("\r", "").replace("\n", "\\n"), skin_text)
    (HERE / "war3mapSkin_resolved.txt").write_text(resolved_skin, encoding="utf-8")
    parsed_text = {
        "war3mapSkin": parse_ini_file(extracted / "war3mapSkin.txt"),
        "war3mapMisc": parse_ini_file(extracted / "war3mapMisc.txt"),
        "war3mapExtra": parse_ini_file(extracted / "war3mapExtra.txt"),
    }
    dump_json(HERE / "auxiliary_text_parsed.json", parsed_text)

    shd_data = (extracted / "war3map.shd").read_bytes()
    shadow = {
        "format": "headerless byte grid", "width": 768, "height": 768,
        "bytes": len(shd_data), "expectedBytes": 768 * 768,
        "byteCounts": {str(k): v for k, v in sorted(Counter(shd_data).items())},
        "sha256": hashlib.sha256(shd_data).hexdigest(),
        "interpretation": "저장된 정적 terrain shadow 격자. 전부 0이어도 런타임 광원·효과의 부재를 뜻하지 않음.",
    }
    dump_json(HERE / "shadow_summary.json", shadow)

    blp = (extracted / "war3mapMap.blp").read_bytes()
    tga = (extracted / "war3mapPreview.tga").read_bytes()
    media = {
        "mapBlp": {
            "magic": fourcc(blp[:4]), "compression": struct.unpack_from("<I", blp, 4)[0],
            "flags": struct.unpack_from("<I", blp, 8)[0], "width": struct.unpack_from("<I", blp, 12)[0],
            "height": struct.unpack_from("<I", blp, 16)[0], "bytes": len(blp), "sha256": hashlib.sha256(blp).hexdigest(),
        },
        "previewTga": {
            "imageType": tga[2], "width": struct.unpack_from("<H", tga, 12)[0],
            "height": struct.unpack_from("<H", tga, 14)[0], "pixelDepth": tga[16],
            "descriptor": tga[17], "bytes": len(tga), "sha256": hashlib.sha256(tga).hexdigest(),
        },
        "mmpIconRows": len(mmp["icons"]),
    }
    dump_json(HERE / "minimap_preview_metadata.json", media)
    with open_csv(HERE / "auxiliary_files_manifest.csv") as handle:
        writer = csv.DictWriter(handle, fieldnames=["file", "size_bytes", "sha256", "source_match"])
        writer.writeheader()
        for row in copied:
            writer.writerow({"file": row["file"], "size_bytes": row["size"], "sha256": row["sha256"], "source_match": row["matchesSource"]})
    return {"mmp": mmp, "shadow": shadow, "media": media, "copied": copied}


def write_limits(lookup: dict) -> None:
    text = """ORDR_S2_2.312[R] 구조 추출 한계

1. 확정적으로 추출 가능한 것
- 정확한 이름을 알고 MPQ 해시 조회가 성공한 파일의 원문과 SHA-256
- W3I 메타데이터, 플레이어 레코드, force, 시작 좌표
- W3E 193×193 꼭짓점 전부와 WPM 768×768 pathing 바이트 전부
- DOO 1,525개 도오다드 레코드 전부, MMP 아이콘 전부
- 루트 war3map.j, WTS, 분할 object data, Skin/Misc/Extra

2. 정확한 경로 조회 실패로 확인된 것
- (listfile), war3map.imp: 전체 파일명·임포트 이름 목록 없음
- war3map.wtg, war3map.wct: GUI 트리거 편집 원본 없음
- war3mapUnits.doo: 표준 사전 배치 유닛·아이템 원본 없음
- war3map.w3r/.w3c/.w3s: 에디터 region/camera/sound 원본 없음

3. '없다'고 단정할 수 없는 것
- listfile이 없으므로 이름을 모르는 사용자 자산은 열거할 수 없다.
- exact lookup 실패는 그 정확한 경로가 없다는 뜻이지, 다른 이름의 동등 자산까지 없다는 뜻이 아니다.
- 실제로 목록에는 없던 LoadingScreen.mdx가 W3I 참조명으로 직접 조회되어 1,296바이트 MDLX로 확인됐다.
- MPQ 암호화 키는 파일명에 의존하므로 이름을 모르는 encrypted entry는 직접 복호화할 수 없다.

4. 보호 테이블 주의
- 원본 MPQ headerSize 2,097,410은 비정상이며 메모리 복사본의 4바이트만 32로 교정했다.
- hash/block table 각 65,536개가 보호용 placeholder로 가득 차 archive.list()의 file_########.dat는 실제 파일 목록이 아니다.
- placeholder 전량 추출, 명목 크기 합산, 파일 개수 65,534를 실자산 개수로 인용하면 안 된다.

5. 원본 재구축 한계
- 실행용 JASS에서 runtime CreateUnit/Rect/Camera/Sound를 일부 추론할 수는 있다.
- 그러나 GUI 트리거 구조·주석·카테고리, Units.doo 배치 원본, 임포트 전체 이름을 원본과 동일하게 복구할 수 없다.
- 이 문서 세트는 실행 데이터 분석용이지 World Editor 원본의 완전한 deprotect 결과가 아니다.
"""
    (HERE / "KNOWN_LIMITS.txt").write_text(text, encoding="utf-8")


def write_readme(source: Path, lookup: dict, w3i: dict, terrain: dict, pathing: dict, doo: dict, auxiliary: dict) -> None:
    text = f"""ORDR_S2_2.312[R] 맵 구조 완전 문서

[원본]
- 파일: {source.name}
- 크기: {source.stat().st_size:,} bytes
- SHA-256: {sha256(source)}
- 원본은 수정하지 않았다. 모든 산출물은 이 폴더에만 생성했다.

[신뢰도 규칙]
- 확정: 원시 바이너리를 문서화된 포맷으로 끝까지 파싱하고 trailing bytes=0을 검증한 값.
- exact lookup: 정확한 파일명으로 MPQ 해시 조회가 성공/실패한 결과.
- 해석 제한: raw byte·bit는 확정이나 의미 명칭을 별도 엔진 사양 없이 붙이지 않은 값.
- 추론: JASS 등 다른 자료와 교차검증해야 하는 내용. 이 구조 문서에서는 원시값과 분리했다.

[좌표계·단위]
- W3E/WPM/DOO의 X는 동쪽으로 증가, Y는 북쪽으로 증가한다.
- CSV는 원본 row-major 순서(index = y*width+x)를 보존한다.
- PNG는 북쪽(+Y)이 위로 보이도록 원시 행을 수직 반전해 그렸다.
- W3E 셀은 128 world units, pathing 셀은 32 world units이다.
- W3E ground_height_normalized=(raw-8192)/512, ground_height_world_z=normalized*128.
- DOO angle 원시는 radian이며 degree 파생 열을 함께 제공한다.

[CSV/JSON 호환]
- 모든 CSV와 CSV.GZ 내부 텍스트는 UTF-8 BOM이다. Windows 메모장·Excel에서 한글을 바로 읽을 수 있다.
- JSON/TXT는 한글을 escape하지 않은 UTF-8이다.
- `.csv.gz`는 7-Zip 등으로 풀면 CSV가 나오며, 첫 행은 헤더다.

[MPQ/표준 파일]
- map_container_header.json: HM3W 외부 헤더와 MPQ 원본 헤더 필드·테이블 offset·보호 이상값.
- mpq_lookup_raw.json: MPQ 직접 조회 원시 결과와 보호 테이블 통계.
- mpq_standard_file_manifest.csv: 알려진 표준·대체 경로 {len(lookup['standardPathRows']):,}개의 존재/부재·크기·SHA-256·추출 상태 전수표.
- direct lookup 성공 {sum(1 for row in lookup['standardPathRows'] if row['existsByExactLookup']):,}개.
- KNOWN_LIMITS.txt: listfile/imp/GUI 원본 부재와 정확한 추출 경계.

[W3I]
- w3i_full.json: W3I 전체 필드. format {w3i['formatVersion']}, playable {w3i['playableWidth']}×{w3i['playableHeight']}.
- w3i_players.csv: 플레이어 {len(w3i['players'])}개 전체. 외부 HM3W maxPlayers는 4이며 0~3번이 실사용 시작 위치다.
- w3i_forces.csv: force {len(w3i['forces'])}개와 32bit mask 전부. 선언 player 범위 밖 비트도 따로 보존했다.

[W3E 지형]
- w3e_vertices.csv.gz: 꼭짓점 {terrain['vertexRows']:,}행 전체. raw/정규화/world Z, 수면, flag, tile/variation/cliff/layer 포함.
- w3e_summary.json: {terrain['vertexWidth']}×{terrain['vertexHeight']} 꼭짓점, {terrain['cellWidth']}×{terrain['cellHeight']} 셀, 타일·flag 통계.
- w3e_heightmap.png / w3e_ground_tile_index.png: 시각 보조. 원시 CSV를 대체하지 않는다.

[WPM pathing]
- wpm_pathing_raw.bin: 헤더를 제외한 row-major {pathing['width']}×{pathing['height']} unsigned byte {pathing['rawPayloadBytes']:,}개. offset=index=y*{pathing['width']}+x.
- wpm_pathing.csv.gz: pathing {pathing['cells']:,}행 전체, raw hex와 8개 bit 열. bit 의미 이름은 추정하지 않았다.
- wpm_summary.json / wpm_raw_values.png: 값·bit 통계와 시각 보조.

[DOO]
- doo_placements.csv: 도오다드 {doo['doodadRows']:,}개 전체. rawcode, 위치, 회전, scale, flags, life, item set, editor creation number 포함.
- doo_summary.json / doo_scatter.png: 56종 집계와 배치 시각 보조.

[MMP·미니맵·보조 설정]
- mmp_icons.csv / mmp_full.json: 아이콘 {len(auxiliary['mmp']['icons'])}개 전체.
- war3mapMap.blp, war3mapPreview.tga: 원본 바이트 사본. war3mapPreview.png는 보기용 파생본.
- minimap_preview_metadata.json: BLP/TGA 크기·형식·해시.
- war3mapSkin.txt, war3mapMisc.txt, war3mapExtra.txt: 원문 사본.
- war3mapSkin_resolved.txt: TRIGSTR를 WTS로 치환한 읽기용 사본.
- auxiliary_text_parsed.json: Skin/Misc/Extra의 모든 섹션·키 구조화.
- war3map.shd / shadow_summary.json: 768×768 정적 그림자 원시 바이트와 통계.
- auxiliary_files_manifest.csv: 보조 파일 크기·해시·원본 일치 여부.

[검증]
- VALIDATION.json: 행 수, 원시 크기, BOM, 해시, 파서 완전 소비 검증.
- DOCUMENT_FILE_MANIFEST.csv: 생성 문서의 크기와 SHA-256. 이 manifest 자체와 생성 스크립트는 자기참조를 피하기 위해 제외한다.

중요: archive.list()의 65,534개 file_########.dat placeholder는 실제 파일 목록이 아니다. 임포트 전체 이름과 GUI 트리거 원본은 복구할 수 없다. 자세한 한계는 KNOWN_LIMITS.txt를 본다.
"""
    (HERE / "README_STRUCTURE.txt").write_text(text, encoding="utf-8")


def count_csv_rows(path: Path, gzipped: bool = False) -> int:
    opener = gzip.open if gzipped else open
    with opener(path, "rt", encoding="utf-8-sig", newline="") as handle:
        return sum(1 for _ in csv.reader(handle)) - 1


def validate_and_manifest(source: Path, lookup: dict, w3i: dict, terrain: dict, pathing: dict, doo: dict, auxiliary: dict) -> dict:
    checks = {
        "sourceUnchangedSha256": sha256(source) == lookup["sourceSha256"],
        "allExtractedLookupHashesMatch": all(row["extractedMatchesLookup"] is not False for row in lookup["standardPathRows"]),
        "w3iFullyParsed": w3i["trailingBytes"] == 0,
        "w3iPlayerRows": count_csv_rows(HERE / "w3i_players.csv") == len(w3i["players"]),
        "w3iForceRows": count_csv_rows(HERE / "w3i_forces.csv") == len(w3i["forces"]),
        "w3eVertexRows": count_csv_rows(HERE / "w3e_vertices.csv.gz", True) == terrain["vertexRows"],
        "wpmRawBytes": (HERE / "wpm_pathing_raw.bin").stat().st_size == pathing["cells"],
        "wpmCsvRows": count_csv_rows(HERE / "wpm_pathing.csv.gz", True) == pathing["cells"],
        "dooRows": count_csv_rows(HERE / "doo_placements.csv") == doo["doodadRows"],
        "mmpRows": count_csv_rows(HERE / "mmp_icons.csv") == len(auxiliary["mmp"]["icons"]),
        "shadowBytes": (HERE / "war3map.shd").stat().st_size == 768 * 768,
        "copiedAssetsMatch": all(row["matchesSource"] is True or row["matchesSource"] == "derived PNG" for row in auxiliary["copied"]),
    }
    csv_paths = [HERE / "mpq_standard_file_manifest.csv", HERE / "w3i_players.csv", HERE / "w3i_forces.csv", HERE / "doo_placements.csv", HERE / "mmp_icons.csv", HERE / "auxiliary_files_manifest.csv"]
    csv_gz_paths = [HERE / "w3e_vertices.csv.gz", HERE / "wpm_pathing.csv.gz"]
    checks["allPlainCsvHaveUtf8Bom"] = all(path.read_bytes().startswith(b"\xef\xbb\xbf") for path in csv_paths)
    checks["allGzipCsvHaveUtf8Bom"] = all(gzip.open(path, "rb").read(3) == b"\xef\xbb\xbf" for path in csv_gz_paths)
    validation = {
        "allPassed": all(checks.values()), "checks": checks,
        "rowCounts": {
            "mpqStandardPaths": count_csv_rows(HERE / "mpq_standard_file_manifest.csv"),
            "w3iPlayers": count_csv_rows(HERE / "w3i_players.csv"),
            "w3iForces": count_csv_rows(HERE / "w3i_forces.csv"),
            "w3eVertices": count_csv_rows(HERE / "w3e_vertices.csv.gz", True),
            "wpmCells": count_csv_rows(HERE / "wpm_pathing.csv.gz", True),
            "dooPlacements": count_csv_rows(HERE / "doo_placements.csv"),
            "mmpIcons": count_csv_rows(HERE / "mmp_icons.csv"),
        },
        "sourceSha256": sha256(source),
    }
    dump_json(HERE / "VALIDATION.json", validation)

    excluded = {"DOCUMENT_FILE_MANIFEST.csv", "generate_structure_docs.py", "mpq_lookup_manifest.mjs"}
    files = [path for path in HERE.iterdir() if path.is_file() and path.name not in excluded]
    with open_csv(HERE / "DOCUMENT_FILE_MANIFEST.csv") as handle:
        writer = csv.DictWriter(handle, fieldnames=["file", "size_bytes", "sha256"])
        writer.writeheader()
        for path in sorted(files):
            writer.writerow({"file": path.name, "size_bytes": path.stat().st_size, "sha256": sha256(path)})
    return validation


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: generate_structure_docs.py <map.w3x> <extracted-dir> <mpq-lookup.json>")
    source, extracted, lookup_path = map(Path, sys.argv[1:])
    source_before = sha256(source)
    base = load_base_parser()
    wts = read_wts(extracted)
    container = {
        "hm3wHeader": base.parse_map_header(source),
        "mpqHeader": base.parse_mpq_header(source),
        "confidenceNote": "원본 읽기 전용 직접 파싱. MPQ headerSize 유효성은 고전 MPQ 32-byte header 기준.",
    }
    dump_json(HERE / "map_container_header.json", container)
    lookup = build_mpq_manifest(lookup_path)
    w3i = build_w3i(base, source, extracted, wts)
    terrain = build_w3e(extracted)
    pathing = build_wpm(extracted, terrain)
    doo = build_doo(extracted, terrain)
    auxiliary = build_auxiliary(base, extracted, wts)
    write_limits(lookup)
    write_readme(source, lookup, w3i, terrain, pathing, doo, auxiliary)
    validation = validate_and_manifest(source, lookup, w3i, terrain, pathing, doo, auxiliary)
    if sha256(source) != source_before:
        raise RuntimeError("source map hash changed")
    print(json.dumps(validation, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
