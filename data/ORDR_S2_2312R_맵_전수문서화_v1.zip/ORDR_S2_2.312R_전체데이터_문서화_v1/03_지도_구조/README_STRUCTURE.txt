ORDR_S2_2.312[R] 맵 구조 완전 문서

[원본]
- 파일: ORDR_S2_2.312[R].w3x
- 크기: 135,303,740 bytes
- SHA-256: 347ebe00181da5b8279da257371b462bc46a7d97ba3ac717f44afe6aba49ed07
- 원본은 수정하지 않았다. 모든 산출물은 이 폴더에만 생성했다.

[신뢰도 규칙]
- 확정: 원시 바이너리를 문서화된 포맷으로 끝까지 파싱하고 trailing bytes=0을 검증한 값.
- exact lookup: 정확한 파일명으로 MPQ 해시 조회가 성공/실패한 결과.
- 해석 제한: raw byte·bit는 확정이나 의미 명칭을 별도 엔진 사양 없이 붙이지 않은 값.
- 추론: JASS 등 다른 자료와 교차검증해야 하는 내용. 이 구조 문서에서는 원시값과 분리했다.

[좌표계·단위]
- W3E/WPM/DOO의 X는 동쪽으로 증가, Y는 북쪽으로 증가한다.
- CSV는 원본 row-major 순서(index = y*width+x)를 보존한다.
- PNG는 북쪽(+Y)이 위로 보이도록 원시 행을 수직 반전해 그렸다.
- W3E 셀은 128 world units, pathing 셀은 32 world units이다.
- W3E ground_height_normalized=(raw-8192)/512, ground_height_world_z=normalized*128.
- DOO angle 원시는 radian이며 degree 파생 열을 함께 제공한다.

[CSV/JSON 호환]
- 모든 CSV와 CSV.GZ 내부 텍스트는 UTF-8 BOM이다. Windows 메모장·Excel에서 한글을 바로 읽을 수 있다.
- JSON/TXT는 한글을 escape하지 않은 UTF-8이다.
- `.csv.gz`는 7-Zip 등으로 풀면 CSV가 나오며, 첫 행은 헤더다.

[MPQ/표준 파일]
- map_container_header.json: HM3W 외부 헤더와 MPQ 원본 헤더 필드·테이블 offset·보호 이상값.
- mpq_lookup_raw.json: MPQ 직접 조회 원시 결과와 보호 테이블 통계.
- mpq_standard_file_manifest.csv: 알려진 표준·대체 경로 48개의 존재/부재·크기·SHA-256·추출 상태 전수표.
- direct lookup 성공 21개.
- KNOWN_LIMITS.txt: listfile/imp/GUI 원본 부재와 정확한 추출 경계.

[W3I]
- w3i_full.json: W3I 전체 필드. format 25, playable 150×140.
- w3i_players.csv: 플레이어 9개 전체. 외부 HM3W maxPlayers는 4이며 0~3번이 실사용 시작 위치다.
- w3i_forces.csv: force 2개와 32bit mask 전부. 선언 player 범위 밖 비트도 따로 보존했다.

[W3E 지형]
- w3e_vertices.csv.gz: 꼭짓점 37,249행 전체. raw/정규화/world Z, 수면, flag, tile/variation/cliff/layer 포함.
- w3e_summary.json: 193×193 꼭짓점, 192×192 셀, 타일·flag 통계.
- w3e_heightmap.png / w3e_ground_tile_index.png: 시각 보조. 원시 CSV를 대체하지 않는다.

[WPM pathing]
- wpm_pathing_raw.bin: 헤더를 제외한 row-major 768×768 unsigned byte 589,824개. offset=index=y*768+x.
- wpm_pathing.csv.gz: pathing 589,824행 전체, raw hex와 8개 bit 열. bit 의미 이름은 추정하지 않았다.
- wpm_summary.json / wpm_raw_values.png: 값·bit 통계와 시각 보조.

[DOO]
- doo_placements.csv: 도오다드 1,525개 전체. rawcode, 위치, 회전, scale, flags, life, item set, editor creation number 포함.
- doo_summary.json / doo_scatter.png: 56종 집계와 배치 시각 보조.

[MMP·미니맵·보조 설정]
- mmp_icons.csv / mmp_full.json: 아이콘 9개 전체.
- LoadingScreen.mdx: W3I가 직접 참조하는 로딩 모델의 MPQ 원본 바이트(1,296 bytes, MDLX).
- war3mapMap.blp, war3mapPreview.tga: 원본 바이트 사본. war3mapPreview.png는 보기용 파생본.
- minimap_preview_metadata.json: BLP/TGA 크기·형식·해시.
- war3mapSkin.txt, war3mapMisc.txt, war3mapExtra.txt: 원문 사본.
- war3mapSkin_resolved.txt: TRIGSTR를 WTS로 치환한 읽기용 사본.
- auxiliary_text_parsed.json: Skin/Misc/Extra의 모든 섹션·키 구조화.
- war3map.shd / shadow_summary.json: 768×768 정적 그림자 원시 바이트와 통계.
- auxiliary_files_manifest.csv: 보조 파일 크기·해시·원본 일치 여부.

[검증]
- VALIDATION.json: 행 수, 원시 크기, BOM, 해시, 파서 완전 소비 검증.
- DOCUMENT_FILE_MANIFEST.csv: 생성 문서의 크기와 SHA-256. 이 manifest 자체와 생성 스크립트는 자기참조를 피하기 위해 제외한다.

중요: archive.list()의 65,534개 file_########.dat placeholder는 실제 파일 목록이 아니다. 임포트 전체 이름과 GUI 트리거 원본은 복구할 수 없다. 자세한 한계는 KNOWN_LIMITS.txt를 본다.
