import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {initSync, MpqArchive} from '../../../tools_npm/node_modules/wow-mpq-web/wow_mpq_web.js';

const [input, extractedDir, output] = process.argv.slice(2);
if (!input || !extractedDir || !output) {
  throw new Error('usage: node mpq_lookup_manifest.mjs <map.w3x> <extracted-dir> <output.json>');
}

const standardPaths = [
  '(attributes)', '(signature)', '(listfile)',
  'war3map.j', 'Scripts\\war3map.j', 'scripts\\war3map.j', 'war3map.lua',
  'war3map.w3i', 'war3map.wts', 'war3map.wtg', 'war3map.wct',
  'war3map.w3u', 'war3map.w3t', 'war3map.w3a', 'war3map.w3b',
  'war3map.w3d', 'war3map.w3h', 'war3map.w3q', 'war3map.w3o',
  'war3mapUnits.doo', 'war3map.doo', 'war3map.w3r', 'war3map.w3c',
  'war3map.w3s', 'war3map.w3v', 'war3map.wpm', 'war3map.w3e',
  'war3map.shd', 'war3map.mmp', 'war3map.imp',
  'war3mapMap.blp', 'war3mapMap.tga', 'war3mapPreview.tga',
  'war3mapSkin.txt', 'war3mapMisc.txt', 'war3mapExtra.txt',
  'UI\\war3mapSkin.txt', 'Units\\CommandStrings.txt',
  'Units\\UnitSkin.txt', 'Units\\AbilitySkin.txt', 'Units\\ItemSkin.txt',
  'Units\\UpgradeSkin.txt', 'Units\\DestructableSkin.txt', 'Units\\DoodadSkin.txt',
  'war3mapImported\\war3mapSkin.txt', 'war3mapImported\\war3mapMisc.txt',
  'LoadingScreen.mdx', 'war3mapImported\\LoadingScreen.mdx'
];

const source = fs.readFileSync(input);
const mpqOffset = source.indexOf(Buffer.from([0x4d, 0x50, 0x51, 0x1a]));
if (mpqOffset < 0) throw new Error('MPQ signature not found');
const archiveBytes = Buffer.from(source.subarray(mpqOffset));
const rawHeaderSize = archiveBytes.readUInt32LE(4);
if (rawHeaderSize < 32 || rawHeaderSize > 1024) archiveBytes.writeUInt32LE(32, 4);

const wasm = fs.readFileSync(new URL('../../../tools_npm/node_modules/wow-mpq-web/wow_mpq_web_bg.wasm', import.meta.url));
initSync({module: wasm});
const archive = new MpqArchive(archiveBytes);

const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const normalize = name => name.replaceAll('\\', '/');
const rows = [];
for (const name of standardPaths) {
  let exists = false;
  let size = null;
  let hash = '';
  let error = '';
  try {
    const bytes = Buffer.from(archive.readFile(name));
    exists = true;
    size = bytes.length;
    hash = sha256(bytes);
  } catch (caught) {
    error = String(caught?.message || caught);
  }
  const extractedPath = path.join(extractedDir, normalize(name));
  const extracted = fs.existsSync(extractedPath) && fs.statSync(extractedPath).isFile();
  let extractedSize = null;
  let extractedSha256 = '';
  if (extracted) {
    const bytes = fs.readFileSync(extractedPath);
    extractedSize = bytes.length;
    extractedSha256 = sha256(bytes);
  }
  rows.push({
    path: name,
    existsByExactLookup: exists,
    size,
    sha256: hash,
    extractionStatus: extracted ? 'extracted' : (exists ? 'lookup_only' : 'not_found_exact_path'),
    extractedRelativePath: extracted ? normalize(name) : '',
    extractedSize,
    extractedSha256,
    extractedMatchesLookup: extracted ? size === extractedSize && hash === extractedSha256 : null,
    lookupError: error
  });
}

const listed = archive.list();
const sample = listed.slice(0, 100);
const sum = key => sample.reduce((total, row) => total + Number(row[key] || 0), 0);
const result = {
  source: path.basename(input),
  sourceSize: source.length,
  sourceSha256: sha256(source),
  mpqOffset,
  originalHeaderSize: rawHeaderSize,
  inMemoryHeaderSize: archiveBytes.readUInt32LE(4),
  archiveFileCountReported: archive.fileCount(),
  archiveEntriesListed: listed.length,
  placeholderEntriesListed: listed.filter(row => /^file_\d+\.dat$/i.test(row.name)).length,
  sampleAnomaly: {
    sampleRows: sample.length,
    nominalUncompressedSizeSum: sum('size'),
    nominalCompressedSizeSum: sum('compressed_size'),
    encryptedRows: sample.filter(row => row.encrypted).length,
    compressedRows: sample.filter(row => row.compressed).length
  },
  standardPathRows: rows
};

fs.writeFileSync(output, JSON.stringify(result, null, 2));
process.stdout.write(JSON.stringify({rows: rows.length, exists: rows.filter(row => row.existsByExactLookup).length, output}, null, 2));
