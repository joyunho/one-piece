#!/usr/bin/env python3
"""Assemble the exhaustive ORDR 2.312[R] documentation package.

This script deliberately never deletes or overwrites a destination.  Build to
a new versioned directory so the uploaded map and earlier reports remain intact.
"""

from __future__ import annotations

import argparse
import hashlib
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
ANALYSIS = ROOT / "map_analysis"


def copy_tree(source: Path, destination: Path) -> None:
    if not source.is_dir():
        raise FileNotFoundError(source)
    shutil.copytree(
        source,
        destination,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )


def copy_file(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_manifest(package: Path) -> None:
    rows = []
    for path in sorted(p for p in package.rglob("*") if p.is_file()):
        relative = path.relative_to(package).as_posix()
        rows.append((relative, path.stat().st_size, sha256(path)))

    target = package / "00_읽어보기" / "FILE_MANIFEST_SHA256.tsv"
    target.parent.mkdir(parents=True, exist_ok=True)
    body = ["relative_path\tbytes\tsha256"]
    body.extend(f"{path}\t{size}\t{digest}" for path, size, digest in rows)
    target.write_text("\ufeff" + "\n".join(body) + "\n", encoding="utf-8")


def make_zip(package: Path, output: Path) -> None:
    if output.exists():
        raise FileExistsError(output)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in package.rglob("*") if p.is_file()):
            arcname = Path(package.name) / path.relative_to(package)
            archive.write(path, arcname.as_posix())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package_dir", type=Path)
    parser.add_argument("zip_path", type=Path)
    args = parser.parse_args()

    package = args.package_dir.resolve()
    zip_path = args.zip_path.resolve()
    if package.exists():
        raise SystemExit(f"destination already exists: {package}")
    if zip_path.exists():
        raise SystemExit(f"zip already exists: {zip_path}")

    package.mkdir(parents=True)
    copy_file(
        ANALYSIS / "full_docs" / "MASTER_README.txt",
        package / "00_읽어보기" / "README_FIRST.txt",
    )
    copy_file(
        ANALYSIS / "full_docs" / "VALIDATION_REPORT.txt",
        package / "00_읽어보기" / "VALIDATION_REPORT.txt",
    )
    copy_tree(ANALYSIS / "full_docs" / "object", package / "01_오브젝트_전수")
    copy_tree(ANALYSIS / "full_docs" / "jass", package / "02_JASS_실행규칙")
    copy_tree(ANALYSIS / "full_docs" / "structure", package / "03_지도_구조")
    copy_tree(ANALYSIS / "extracted", package / "04_원본_표준파일_추출")

    tools = package / "05_재현_도구"
    for source in (
        ANALYSIS / "extract_mpq.mjs",
        ANALYSIS / "parse_v3_objects.py",
        ANALYSIS / "validate_full_docs.py",
        ANALYSIS / "build_full_package.py",
    ):
        copy_file(source, tools / source.name)

    write_manifest(package)
    make_zip(package, zip_path)
    print(
        f"package={package}\n"
        f"zip={zip_path}\n"
        f"files={sum(1 for p in package.rglob('*') if p.is_file())}\n"
        f"package_bytes={sum(p.stat().st_size for p in package.rglob('*') if p.is_file())}\n"
        f"zip_bytes={zip_path.stat().st_size}\n"
        f"zip_sha256={sha256(zip_path)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
