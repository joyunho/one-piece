from __future__ import annotations

import json
import re
import struct
import sys
from collections import Counter
from pathlib import Path


class Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def take(self, size: int) -> bytes:
        end = self.pos + size
        if end > len(self.data):
            raise ValueError(f"read past EOF at {self.pos} + {size} > {len(self.data)}")
        value = self.data[self.pos:end]
        self.pos = end
        return value

    def i32(self) -> int:
        return struct.unpack("<i", self.take(4))[0]

    def u32(self) -> int:
        return struct.unpack("<I", self.take(4))[0]

    def f32(self) -> float:
        return struct.unpack("<f", self.take(4))[0]

    def cstring(self) -> str:
        end = self.data.find(b"\0", self.pos)
        if end < 0:
            raise ValueError(f"unterminated string at {self.pos}")
        raw = self.data[self.pos:end]
        self.pos = end + 1
        return raw.decode("utf-8", errors="replace")


def fourcc(raw: bytes) -> str:
    if raw == b"\0\0\0\0":
        return ""
    return raw.decode("latin1")


def parse_mod(reader: Reader, optional_ints: bool) -> dict:
    field = fourcc(reader.take(4))
    value_type = reader.i32()
    level = reader.i32() if optional_ints else 0
    data_pointer = reader.i32() if optional_ints else 0
    if value_type == 0:
        value = reader.i32()
    elif value_type in (1, 2):
        value = reader.f32()
    elif value_type == 3:
        value = reader.cstring()
    else:
        raise ValueError(f"unknown variable type {value_type} at {reader.pos - 4}")
    end_id = fourcc(reader.take(4))
    return {
        "field": field,
        "type": value_type,
        "level": level,
        "dataPointer": data_pointer,
        "value": value,
        "endId": end_id,
    }


def parse_table(reader: Reader, version: int, optional_ints: bool, label: str) -> list[dict]:
    count = reader.u32()
    if count > 100000:
        raise ValueError(f"implausible {label} object count {count}")
    objects = []
    for index in range(count):
        old_id = fourcc(reader.take(4))
        new_id = fourcc(reader.take(4))
        sets = []
        if version >= 3:
            set_count = reader.u32()
            if set_count > 100000:
                raise ValueError(f"implausible set count {set_count} for {old_id}/{new_id}")
            for _ in range(set_count):
                set_id = reader.i32()
                mod_count = reader.u32()
                if mod_count > 100000:
                    raise ValueError(f"implausible mod count {mod_count} for {old_id}/{new_id}")
                modifications = [parse_mod(reader, optional_ints) for _ in range(mod_count)]
                sets.append({"id": set_id, "modifications": modifications})
        else:
            mod_count = reader.u32()
            modifications = [parse_mod(reader, optional_ints) for _ in range(mod_count)]
            sets.append({"id": 0, "modifications": modifications})
        objects.append({
            "table": label,
            "index": index,
            "oldId": old_id,
            "newId": new_id,
            "id": new_id or old_id,
            "sets": sets,
            "modifications": [mod for group in sets for mod in group["modifications"]],
        })
    return objects


def parse_object_file(path: Path, optional_ints: bool) -> dict:
    reader = Reader(path.read_bytes())
    version = reader.i32()
    original = parse_table(reader, version, optional_ints, "original")
    custom = parse_table(reader, version, optional_ints, "custom")
    return {
        "file": path.name,
        "version": version,
        "original": original,
        "custom": custom,
        "remainingBytes": len(reader.data) - reader.pos,
    }


def parse_wts(path: Path) -> tuple[dict[int, str], list[dict]]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    strings: dict[int, str] = {}
    records: list[dict] = []
    matches = list(re.finditer(r"(?m)^STRING\s+(\d+)\s*\r?$", text))
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        block = text[match.end():end]
        comment_match = re.search(r"(?m)^//\s*(.*?)\s*\r?$", block)
        open_brace = block.find("{")
        close_brace = block.rfind("}")
        value = block[open_brace + 1:close_brace].strip("\r\n") if open_brace >= 0 and close_brace > open_brace else ""
        string_id = int(match.group(1))
        strings[string_id] = value
        comment = comment_match.group(1) if comment_match else ""
        parsed = {"stringId": string_id, "comment": comment, "value": value}
        meta = re.match(r"([^:]+):\s*(\S+)\s*\((.*?)\),\s*(.*?)\s*\((.*)\)$", comment)
        if meta:
            field_match = re.search(r"\(([^()]+)\)\s*$", meta.group(5))
            parsed.update({
                "kind": meta.group(1),
                "objectId": meta.group(2),
                "objectLabel": meta.group(3),
                "fieldLabel": meta.group(4),
                "fieldDescription": meta.group(5),
                "fieldId": field_match.group(1) if field_match else "",
            })
        records.append(parsed)
    return strings, records


def resolve_string(value, strings: dict[int, str]):
    if not isinstance(value, str):
        return value
    match = re.fullmatch(r"TRIGSTR_0*(\d+)", value.strip())
    return strings.get(int(match.group(1)), value) if match else value


COLOR_RE = re.compile(r"\|c[0-9A-Fa-f]{8}|\|r", re.IGNORECASE)
GRADE_WORDS = [
    "안흔함", "흔함", "특별", "희귀", "전설", "히든", "왜곡", "변화", "제한",
    "불멸", "영원", "초월", "세라핌", "해적선", "신비", "랜덤", "보스", "오로성",
]


def clean_text(value: str) -> str:
    return re.sub(r"\s+", " ", COLOR_RE.sub("", value or "")).strip()


def main() -> None:
    base = Path(sys.argv[1] if len(sys.argv) > 1 else "map_analysis/extracted")
    out = Path(sys.argv[2] if len(sys.argv) > 2 else "map_analysis/parsed")
    out.mkdir(parents=True, exist_ok=True)
    strings, wts_records = parse_wts(base / "war3map.wts")
    specs = {
        "unit": ("w3u", False),
        "item": ("w3t", False),
        "ability": ("w3a", True),
        "destructable": ("w3b", False),
        "doodad": ("w3d", True),
        "buff": ("w3h", False),
        "upgrade": ("w3q", True),
    }
    parsed = {}
    summary = {"wtsStrings": len(strings), "wtsAnnotated": sum(1 for row in wts_records if row.get("kind")), "types": {}}
    for kind, (extension, optional) in specs.items():
        result = parse_object_file(base / f"war3map.{extension}", optional)
        objects = result["original"] + result["custom"]
        for obj in objects:
            for mod in obj["modifications"]:
                mod["resolved"] = resolve_string(mod["value"], strings)
        fields = Counter(mod["field"] for obj in objects for mod in obj["modifications"])
        summary["types"][kind] = {
            "file": result["file"],
            "version": result["version"],
            "originalObjects": len(result["original"]),
            "customObjects": len(result["custom"]),
            "objects": len(objects),
            "modificationSets": sum(len(obj["sets"]) for obj in objects),
            "modifications": sum(len(obj["modifications"]) for obj in objects),
            "remainingBytes": result["remainingBytes"],
            "topFields": fields.most_common(25),
        }
        parsed[kind] = result

    wts_by_object: dict[str, list[dict]] = {}
    for row in wts_records:
        if row.get("objectId"):
            wts_by_object.setdefault(row["objectId"], []).append(row)

    catalog = {}
    name_fields = {"unam", "anam", "fnam", "gnam", "bnam", "dnam"}
    for kind, result in parsed.items():
        rows = []
        for obj in result["original"] + result["custom"]:
            field_rows: dict[str, list] = {}
            for mod in obj["modifications"]:
                field_rows.setdefault(mod["field"], []).append(mod["resolved"])
            annotation_rows = wts_by_object.get(obj["id"], [])
            names = [str(value) for field in name_fields for value in field_rows.get(field, []) if str(value).strip()]
            names += [row["value"] for row in annotation_rows if row.get("fieldId") in name_fields]
            display = clean_text(names[-1]) if names else clean_text(annotation_rows[0].get("objectLabel", "")) if annotation_rows else ""
            grade = next((word for word in GRADE_WORDS if word in display), "")
            rows.append({
                "id": obj["id"],
                "oldId": obj["oldId"],
                "newId": obj["newId"],
                "table": obj["table"],
                "name": display,
                "grade": grade,
                "abilityIds": str(field_rows.get("uabi", [""])[-1]).split(",") if kind == "unit" and field_rows.get("uabi") else [],
                "fields": field_rows,
                "annotations": annotation_rows,
            })
        catalog[kind] = rows

    summary["wtsKinds"] = Counter(row.get("kind", "unannotated") for row in wts_records)
    summary["unitGrades"] = Counter(row["grade"] or "미분류" for row in catalog["unit"])
    summary["namedUnits"] = sum(bool(row["name"]) for row in catalog["unit"])
    summary["namedAbilities"] = sum(bool(row["name"]) for row in catalog["ability"])
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "objects.json").write_text(json.dumps(parsed, ensure_ascii=False), encoding="utf-8")
    (out / "catalog.json").write_text(json.dumps(catalog, ensure_ascii=False), encoding="utf-8")
    (out / "wts_records.json").write_text(json.dumps(wts_records, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=dict))


if __name__ == "__main__":
    main()
