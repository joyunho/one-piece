import fs from 'node:fs';
import path from 'node:path';
import {initSync, MpqArchive} from '../tools_npm/node_modules/wow-mpq-web/wow_mpq_web.js';

const input = process.argv[2];
const output = process.argv[3];
if (!input || !output) throw new Error('usage: node extract_mpq.mjs <map.w3x> <output-dir>');

fs.mkdirSync(output, {recursive: true});
const source = fs.readFileSync(input);
const mpqOffset = source.indexOf(Buffer.from([0x4d, 0x50, 0x51, 0x1a]));
if (mpqOffset < 0) throw new Error('MPQ signature not found');
const archiveBytes = Buffer.from(source.subarray(mpqOffset));
const originalHeaderSize = archiveBytes.readUInt32LE(4);
if (originalHeaderSize < 32 || originalHeaderSize > 1024) archiveBytes.writeUInt32LE(32, 4);

const wasm = fs.readFileSync(new URL('../tools_npm/node_modules/wow-mpq-web/wow_mpq_web_bg.wasm', import.meta.url));
initSync({module: wasm});
const archive = new MpqArchive(archiveBytes);

const known = [
  '(attributes)', '(signature)', '(listfile)',
  'war3map.j', 'Scripts\\war3map.j', 'scripts\\war3map.j', 'war3map.lua',
  'war3map.w3i', 'war3map.wts', 'war3map.wtg', 'war3map.wct',
  'war3map.w3u', 'war3map.w3t', 'war3map.w3a', 'war3map.w3b',
  'war3map.w3d', 'war3map.w3h', 'war3map.w3q', 'war3map.w3o',
  'war3mapUnits.doo', 'war3map.doo', 'war3map.w3r', 'war3map.w3c',
  'war3map.w3s', 'war3map.w3v', 'war3map.wpm', 'war3map.w3e',
  'war3map.shd', 'war3map.mmp', 'war3map.imp',
  'war3mapMap.blp', 'war3mapMap.tga', 'war3mapPreview.tga',
  'war3mapSkin.txt', 'war3mapMisc.txt', 'war3mapExtra.txt',
  'UI\\war3mapSkin.txt', 'Units\\CommandStrings.txt',
  'Units\\UnitSkin.txt', 'Units\\AbilitySkin.txt', 'Units\\ItemSkin.txt',
  'Units\\UpgradeSkin.txt', 'Units\\DestructableSkin.txt', 'Units\\DoodadSkin.txt',
  'war3mapImported\\war3mapSkin.txt', 'war3mapImported\\war3mapMisc.txt'
];

function safeRelative(name) {
  return name.replaceAll('\\', '/').split('/').filter(part => part && part !== '.' && part !== '..').join('/');
}

const extracted = [];
const missing = [];
function extract(name, kind = 'known') {
  if (extracted.some(row => row.name.toLowerCase() === name.toLowerCase())) return null;
  try {
    const bytes = Buffer.from(archive.readFile(name));
    const relative = safeRelative(name);
    const target = path.join(output, relative);
    fs.mkdirSync(path.dirname(target), {recursive: true});
    fs.writeFileSync(target, bytes);
    extracted.push({name, relative, size: bytes.length, kind});
    return bytes;
  } catch (error) {
    if (kind === 'known') missing.push({name, error: String(error && error.message || error)});
    return null;
  }
}

for (const name of known) extract(name);

function importedNames(bytes) {
  if (!bytes || bytes.length < 8) return [];
  const count = bytes.readUInt32LE(4);
  if (count > 100000) return [];
  const names = [];
  let cursor = 8;
  for (let index = 0; index < count && cursor < bytes.length; index += 1) {
    const flag = bytes[cursor++];
    const end = bytes.indexOf(0, cursor);
    if (end < 0) break;
    const raw = bytes.subarray(cursor, end).toString('utf8');
    cursor = end + 1;
    const name = flag === 5 || raw.includes('\\') ? raw : `war3mapImported\\${raw}`;
    names.push({flag, raw, name});
  }
  return names;
}

const imp = extracted.find(row => row.name.toLowerCase() === 'war3map.imp');
const impBytes = imp ? fs.readFileSync(path.join(output, imp.relative)) : null;
const imports = importedNames(impBytes);
const usefulImportPattern = /\.(?:txt|ini|slk|j|lua|json|csv|tsv|fdf|toc|pld|cfg|md)$/i;
for (const row of imports) if (usefulImportPattern.test(row.name)) extract(row.name, 'text-import');

const archiveRows = archive.list();
const summary = {
  source: path.basename(input),
  sourceSize: source.length,
  mpqOffset,
  originalHeaderSize,
  repairedHeaderSize: archiveBytes.readUInt32LE(4),
  archiveFileCountReported: archive.fileCount(),
  archiveEntriesReported: archiveRows.length,
  archivePlaceholderEntries: archiveRows.filter(row => /^file_\d+\.dat$/i.test(row.name)).length,
  extracted,
  missing,
  imports,
  archiveSample: archiveRows.slice(0, 100)
};
fs.writeFileSync(path.join(output, '_extraction_summary.json'), JSON.stringify(summary, null, 2));
process.stdout.write(JSON.stringify({
  mpqOffset,
  originalHeaderSize,
  fileCount: summary.archiveFileCountReported,
  extracted: extracted.map(row => `${row.name}:${row.size}`),
  imports: imports.length,
  textImports: extracted.filter(row => row.kind === 'text-import').length
}, null, 2));

