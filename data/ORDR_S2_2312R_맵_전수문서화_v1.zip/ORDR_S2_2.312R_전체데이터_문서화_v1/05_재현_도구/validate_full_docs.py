#!/usr/bin/env python3
"""Validate the exhaustive ORDR 2.312[R] documentation tree.

The validator is intentionally generic: every JSON document must parse, every
CSV/TSV document must have a stable column count, every text file must decode
as UTF-8 (BOM is accepted), and every packaged file is hashed.  A small set of
domain invariants guards the counts that were independently established from
the Warcraft object and map formats.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
from typing import Any


CANONICAL_INVARIANTS = {
    "units_1406.tsv": 1406,
    "abilities_1642.tsv": 1642,
    "unit_ability_links_5279.tsv": 5279,
    "recipes_150.csv": 150,
    "items_14.tsv": 14,
    "upgrades_110.tsv": 110,
    "buffs_326.tsv": 326,
    "wts_strings_10629.csv": 10629,
    "01_round_waves.csv": 65,
    "04_rawcode_occurrences.csv": 13074,
    "jass_function_index.csv": 2691,
    "doo_placements.csv": 1525,
    "w3i_players.csv": 9,
    "mmp_icons.csv": 9,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8-sig", newline="")
    return path.open("r", encoding="utf-8-sig", newline="")


def json_record_count(value: Any) -> int:
    if isinstance(value, list):
        return len(value)
    if isinstance(value, dict):
        for key in ("records", "rows", "objects", "items", "data"):
            if isinstance(value.get(key), list):
                return len(value[key])
        return len(value)
    return 1


def validate_json(path: Path) -> tuple[int, str]:
    with open_text(path) as handle:
        value = json.load(handle)
    return json_record_count(value), "json"


def validate_delimited(path: Path, delimiter: str) -> tuple[int, str]:
    with open_text(path) as handle:
        reader = csv.reader(handle, delimiter=delimiter)
        header = next(reader, None)
        if header is None:
            return 0, "empty-delimited"
        width = len(header)
        count = 0
        for line_number, row in enumerate(reader, start=2):
            if len(row) != width:
                raise ValueError(
                    f"column mismatch at line {line_number}: {len(row)} != {width}"
                )
            count += 1
    return count, f"delimited({width} columns)"


def validate_text(path: Path) -> tuple[int, str]:
    with open_text(path) as handle:
        count = sum(1 for _ in handle)
    return count, "text-lines"


def classify_and_validate(path: Path) -> tuple[int | None, str]:
    lower = path.name.lower()
    if lower.endswith(".json") or lower.endswith(".json.gz"):
        return validate_json(path)
    if lower.endswith(".csv") or lower.endswith(".csv.gz"):
        return validate_delimited(path, ",")
    if lower.endswith(".tsv") or lower.endswith(".tsv.gz"):
        return validate_delimited(path, "\t")
    if path.suffix.lower() in {".txt", ".md", ".j", ".mjs", ".py"}:
        return validate_text(path)
    return None, "binary"


def matching_domain(name: str) -> str | None:
    lower = name.lower()
    candidates = [
        ("wts", ("wts", "string")),
        ("recipe", ("recipe", "combination", "조합")),
        ("upgrade", ("upgrade", "w3q")),
        ("item", ("item", "w3t")),
        ("buff", ("buff", "effect", "w3h")),
        ("doodad", ("doodad_placement", "doo_placement")),
        ("round", ("round", "wave")),
        ("abil", ("ability", "abilities", "w3a")),
        ("unit", ("unit", "w3u")),
    ]
    for domain, needles in candidates:
        if any(needle in lower for needle in needles):
            return domain
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    root = args.root.resolve()
    if not root.is_dir():
        raise SystemExit(f"not a directory: {root}")

    rows: list[dict[str, Any]] = []
    errors: list[str] = []
    canonical_observed: dict[str, int] = {}

    for path in sorted(
        p
        for p in root.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
    ):
        relative = path.relative_to(root).as_posix()
        try:
            count, kind = classify_and_validate(path)
            if path.name in CANONICAL_INVARIANTS and count is not None:
                canonical_observed[path.name] = count
            rows.append(
                {
                    "path": relative,
                    "bytes": path.stat().st_size,
                    "sha256": sha256(path),
                    "kind": kind,
                    "records_or_lines": "" if count is None else count,
                    "status": "OK",
                }
            )
        except Exception as exc:  # validation must report every bad file
            errors.append(f"{relative}: {exc}")
            rows.append(
                {
                    "path": relative,
                    "bytes": path.stat().st_size,
                    "sha256": sha256(path),
                    "kind": "error",
                    "records_or_lines": "",
                    "status": f"ERROR: {exc}",
                }
            )

    invariant_lines: list[str] = []
    for filename, expected in CANONICAL_INVARIANTS.items():
        value = canonical_observed.get(filename)
        status = "OK" if value == expected else "FAIL"
        invariant_lines.append(f"{status}\t{filename}\tobserved={value}\texpected={expected}")
        if status == "FAIL":
            errors.append(f"canonical invariant {filename}: {value} != {expected}")

    report = args.report or root / "VALIDATION_REPORT.txt"
    report.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "ORDR S2 2.312[R] exhaustive documentation validation",
        f"root={root}",
        f"files={len(rows)}",
        f"bytes={sum(int(row['bytes']) for row in rows)}",
        f"errors={len(errors)}",
        "",
        "[DOMAIN INVARIANTS]",
        *invariant_lines,
        "",
        "[ERRORS]",
        *(errors or ["none"]),
        "",
        "[FILE MANIFEST]",
        "status\tbytes\trecords_or_lines\tsha256\tpath",
    ]
    lines.extend(
        f"{row['status']}\t{row['bytes']}\t{row['records_or_lines']}\t{row['sha256']}\t{row['path']}"
        for row in rows
    )
    report.write_text("\ufeff" + "\n".join(lines) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {"files": len(rows), "errors": errors, "canonical": canonical_observed},
            ensure_ascii=False,
        )
    )
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
