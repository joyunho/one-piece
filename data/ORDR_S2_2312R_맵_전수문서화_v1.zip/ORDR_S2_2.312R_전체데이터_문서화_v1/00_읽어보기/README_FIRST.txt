===============================================================================
 ORDR S2 2.312[R] 전체 복구 가능 데이터 문서화 — 먼저 읽기
===============================================================================

작성일       : 2026-08-11
원본         : ORDR_S2_2.312[R].w3x
원본 크기    : 135,303,740 bytes
원본 SHA-256 : 347ebe00181da5b8279da257371b462bc46a7d97ba3ac717f44afe6aba49ed07
데이터 버전  : 2.312R 전용


1. 이 패키지는 무엇인가
-------------------------------------------------------------------------------

이 패키지는 앞서 만든 요약 보고서를 확장한 "전수 문서화본"이다.
맵에서 정적으로 복구 가능한 모든 표준 데이터와 실행 규칙을 다음 세 형태로
함께 담았다.

  1) 사람이 읽는 TXT 설명서와 규칙집
  2) 메모장·Excel에서 열 수 있는 UTF-8 BOM CSV/TSV 전수표
  3) 프로그램이 손실 없이 읽을 수 있는 UTF-8 JSON과 원시 바이너리

단순 집계가 아니라 각 오브젝트의 모든 modification, 각 JASS rawcode 출현,
함수·호출 간선, 1~65라운드, 조합식과 미해소 항목까지 보존했다.

중요한 표현:

  "전체 데이터" = 이 보호형 W3X에서 이름 또는 표준 구조를 통해 복구할 수
  있는 모든 데이터다. listfile·GUI 트리거 원본처럼 맵 자체에 없거나 이름을
  알 수 없는 임포트까지 복원했다는 뜻은 아니다. 복구 불가능 영역도 숨기지
  않고 별도 한계 원장에 기록했다.


2. 앞선 요약본과 달라진 점
-------------------------------------------------------------------------------

앞선 메모장은 핵심 결론 744줄을 정리한 감사 보고서였다. 이번 패키지는 실제
전체 행을 담는다.

  - 유닛 1,406개 전체 정의와 수정값 44,997행
  - 능력 1,642개 전체 정의와 수정값 22,584행
  - 유닛-능력 연결 5,279행
  - WTS 문자열 10,629개와 TRIGSTR 역색인 8,751행
  - UI 조합식 150개, 재료 433건
  - JASS 조합·변환·관계 후보 총 549행
  - 라운드 65개와 보스 8개
  - JASS 함수 2,691개와 함수 호출 간선 6,520개
  - rawcode 출현 13,074행, 고유 2,371개
  - 피해·CC 후보 callsite 1,397행
  - 지형 꼭짓점 37,249행
  - pathing 셀 589,824행
  - 도오다드 배치 1,525행

정정:

  - 앞선 요약본의 원본 SHA-256 표기는 중간 문자열이 빠진 축약값이었다.
    위에 적은 64자리
    `347ebe00181da5b8279da257371b462bc46a7d97ba3ac717f44afe6aba49ed07`
    이 검증된 전체 SHA-256이다.


3. 폴더를 보는 순서
-------------------------------------------------------------------------------

00_읽어보기
  - README_FIRST.txt: 현재 파일
  - VALIDATION_REPORT.txt: 패키지 전수 검증 결과
  - FILE_MANIFEST_SHA256.tsv: 모든 파일의 크기와 SHA-256

01_오브젝트_전수
  - 유닛, 능력, 조합, 아이템, 업그레이드, 버프, WTS 원장
  - 먼저 README_OBJECT.txt를 읽는다.

02_JASS_실행규칙
  - 라운드, 난이도, 오로성, 항법, 보상, 명령, 함수, rawcode, 피해·CC 원장
  - 먼저 README_JASS.txt와 07_confidence_ledger.txt를 읽는다.

03_지도_구조
  - MPQ, W3I, 지형, pathing, 배치, 미니맵, 원시 시각 자료
  - 먼저 README_STRUCTURE.txt와 KNOWN_LIMITS.txt를 읽는다.

04_원본_표준파일_추출
  - 맵에서 직접 꺼낸 war3map.j, WTS, 분할 object, 지형과 보조 파일
  - 가공 문서의 근거 보존용이다.

05_재현_도구
  - MPQ 추출, object v3 파싱, 전수 검증, 패키징 스크립트


4. 오브젝트 데이터 세부 목록
-------------------------------------------------------------------------------

핵심 원장

  units_1406.tsv / units_1406.json
    rawcode, base rawcode, 이름, 등급, 폼 휴리스틱, 능력, HP/MP,
    공격·방어·이동·사거리, 아이콘·모델·요구·업그레이드,
    모든 원본 field와 resolved WTS 값

  unit_modifications_44997.tsv
    유닛 modification 44,997개 전수
    field/type/level/dataPointer/value/endMarker 보존

  abilities_1642.tsv / abilities_raw_1642.json
    능력 1,642개 전수, 레벨·쿨타임·범위·지속·대상·버프·툴팁·data field

  ability_modifications_22584.tsv
    능력 modification 22,584개 전수

  unit_ability_links_5279.tsv / json
    유닛 rawcode → 능력 rawcode 5,279개 연결

조합 원장

  recipes_150.csv / json / txt
    object UI에 명시된 조합식 150개
    목표·등급·목표 rawcode·재료·수량·재료 rawcode·목재·골드·아이템·
    토큰·라운드 제한·hotkey·원문·근거

  recipe_unresolved_materials.tsv / json
    자동 연결하지 못한 단 1건

기타 object

  items_14.tsv/json
  upgrades_110.tsv/json
  buffs_326.tsv/json
  doodads_39.tsv/json
  destructibles_12.tsv/json

문자열과 분류

  wts_strings_10629.csv/json
    STRING 0을 포함한 WTS 10,629개 전수

  trigstr_reverse_index_8751.tsv/json
    어느 object field가 어느 TRIGSTR를 참조하는지 8,751행

  classification_ledger_1406.tsv
    모든 유닛 정의의 등급·폼 판정과 신뢰도

  classification_unresolved.tsv
    의미 분류를 자동 확정하지 않은 281개

  FIELD_DICTIONARY.tsv
    주요 Warcraft object field ID 설명


5. 오브젝트 분류 결과를 읽을 때 주의할 점
-------------------------------------------------------------------------------

raw definition 1,406개는 실제 선택 가능한 고유 유닛 1,406개라는 뜻이 아니다.

폼 휴리스틱 분포

  더미                  794
  플레이 가능 후보      267
  보스/스토리            31
  보상/상자              17
  선박                    6
  UI/제어                10
  미확정                281
  합계                1,406

등급 이름이 보이는 정의 수

  흔함 9 / 안흔함 14 / 특별 33 / 희귀 45 / 전설 47 / 히든 24 /
  왜곡 8 / 변화 7 / 제한 12 / 초월 16 / 불멸 27 / 영원 15 /
  세라핌 4 / 신비 16 / 랜덤전용 14

이 수에는 변신형, 분신, 소환물, 공격 더미가 섞여 있다. 코치 로스터는
classification_ledger를 기초로 수동 확인한 canonical family를 별도로 만들어야
한다. `미확정 281`은 원시 데이터가 누락됐다는 뜻이 아니라 의미상 폼을 자동
확정하지 않았다는 뜻이다.


6. 조합식 완전성
-------------------------------------------------------------------------------

object UI 조합식

  - 목표 150 / 150 rawcode 연결
  - 재료 433건
  - 재료 rawcode 자동 해소 432건
  - 미해소 1건

미해소 1건

  - 능력 A19T, 목표 `쿠치키 뱌쿠야 - 신비`
  - 레시피 표기 `에이스 - 왜곡`
  - object 실제 이름 `포트거스.D.에이스 - 왜곡`
  - 명칭 차이가 강하게 의심되지만 자동 추측으로 합치지 않았다.

JASS 보조 조합·변환 원장 549행

  - WTS UI 조합식 150
  - 채팅 조합 명령 등록 22
  - 그린블러드 명시 변환 4
  - Create/Kill 변환·소환 후보 81
  - SaveInteger raw 관계 292

주의:

  - 150개 UI 조합식은 object 원장을 정답 원장으로 사용한다.
  - JASS 후보 81개에는 소환 스킬이 섞일 수 있다.
  - SaveInteger 292개는 raw 관계일 뿐 조합 재료라는 뜻이 아니다.
  - confidence가 `후보/미확정`인 행은 추천 엔진에 바로 넣지 않는다.


7. JASS 실행 데이터 세부 목록
-------------------------------------------------------------------------------

라운드와 규칙

  01_round_waves.csv/json/txt
    1~65라운드, 일반 웨이브·보스 rawcode, 이름, 타이머, 구간, 근거줄

  02_rules_confirmed.csv/txt
    난이도 1~6, 오로성, 모드, 항법의 확정·표시 규칙 34행

  02_rule_source_blocks.txt
    관련 JASS 원문 블록 1,016줄

  03_gameplay_evidence.csv/txt
    보상·도박·리롤·변화·세라핌·보물·스토리·퀘스트·카운터의
    원문 근거 1,099행

  03_chat_commands.csv
    채팅 명령 등록 190행과 callback 기호

조합·상태 관계

  jass_recipe_rules.csv/json
    위에서 설명한 549행

  jass_rawcode_relations.csv
    SaveInteger 기반 raw 관계 292행, 의미 미확정

  jass_transform_candidates.csv
    CreateUnit과 Kill/Remove가 공존하는 함수 후보 81행

  jass_ai_table_edges.csv
    hashtable parent/value 관계 264행, 의미 미확정

전체 script 역색인

  04_rawcode_occurrences.csv
    모든 rawcode 출현 13,074행, 원본 줄·함수·문맥 포함

  04_rawcode_ledger.csv/json
    고유 rawcode 2,371개별 출현 횟수·줄·함수·이름 해소 상태
    이름 해소 2,149 / 미해소 222

  jass_function_index.csv
    전체 함수 2,691개, 줄 범위·매개변수·return·callee·rawcode refs

  jass_call_edges.csv
    함수 caller→callee 정적 간선 6,520개

  06_jass_strings.csv
    JASS 문자열 리터럴 6,851행

  06_call_statistics.csv
    call 이름 605종과 빈도

  06_hex_constants.csv
    고유 8자리 $HEX 상수 2,371개

전투 역할 후보

  05_damage_cc_callsites.csv
    피해·스턴·이감·CC·능력 추가 후보 호출 1,397행

  05_callback_registrations.csv
    rawcode→callback symbol→함수 등록 526행

  - callsite 중 등록 유닛 후보까지 자동 연결된 행: 348
  - 나머지는 호출 자체는 확정이지만 특정 유닛 역할 귀속은 추가 분석 대상이다.


8. 라운드와 코치 규칙에서 확정된 중요 사항
-------------------------------------------------------------------------------

  - 실행 최종 라운드: 65
  - 보스: 10 아론, 20 크로커다일, 30 에넬, 40 루치,
          50 센고쿠, 55 도플라밍고, 60 빅맘, 65 카이도
  - 1~50 일반 타이머 35초, 10단위 보스 60초
  - 50라 이후 신세계 전환 70초, 51~65 타이머 32초
  - 악몽 유닛 카운트 70, 41라부터 50
  - 악몽 적 마방 +10%, 보스 HP +200%, 적 이동속도 +50%
  - 35라까지 13.와노쿠니 파괴 필요
  - 희귀 리롤 기본 2회, 일반 목재2
  - 카지노 +1, 리스크 헷지 +2·목재0
  - 변화 기본 2회, 세라핌 그린블러드 1회
  - 152킬은 희귀 보상이 아니라 진화체 활성 카운터
  - 전역 상위 최대2 규칙은 없음
  - 실제 최상위 3기·4기 퀘스트 코드가 살아 있음
  - 패왕의 길은 최상위 1기, 계엄령은 최상위 조합 금지


9. 방주맥심 확인값
-------------------------------------------------------------------------------

유닛 h03X

  - 기본 공격 사거리 700
  - 기본 공격 주기 약 0.64초
  - MP 150

A0BH

  - 기본공격 4명
  - 공격 시 14%
  - 범위 600
  - 마법 피해 200,000
  - 3초간 이동속도 30% 감소

A0BG

  - 마나 150, 범위 800
  - 마법 피해 2,150,000
  - 스턴 1.2초
  - 마법 방어 10% 감소
  - 폭발형 피해 10% 증폭

코치는 맥심을 마딜+이감+스턴+마방깎+폭발형 증폭으로 분류해야 한다.


10. 지도 구조 데이터 세부 목록
-------------------------------------------------------------------------------

MPQ와 파일

  mpq_standard_file_manifest.csv
    알려진 표준·대체 경로 48개 전수 조회
    정확한 파일명 direct lookup 성공 21개

  map_container_header.json / mpq_lookup_raw.json
    HM3W·MPQ 헤더와 보호 테이블 구조

  KNOWN_LIMITS.txt
    listfile·imp·GUI 원본·이름 없는 임포트의 복구 한계

W3I

  w3i_full.json
  w3i_players.csv  9행
  w3i_forces.csv   2행

  - 실사용 플레이어는 0~3의 4인
  - 4~8은 플레이어5·항해 포인트·모험경로·조합식·NPC 시스템 레코드

지형

  w3e_vertices.csv.gz
    193×193 = 37,249 꼭짓점 전수
    raw 높이, 정규화 높이, world Z, 수면, flag, tile, variation, cliff

  w3e_heightmap.png
  w3e_ground_tile_index.png

Pathing

  wpm_pathing_raw.bin
    768×768 = 589,824 raw byte

  wpm_pathing.csv.gz
    각 셀의 좌표, raw hex, 8개 bit 열 589,824행

  wpm_raw_values.png

배치

  doo_placements.csv
    도오다드 1,525개, rawcode·좌표·회전·scale·flags·life 전수

  doo_scatter.png

미니맵·설정

  mmp_icons.csv/json      미니맵 아이콘 9개
  war3mapMap.blp          미니맵 원본
  war3mapPreview.tga/png  미리보기 원본·보기용 PNG
  war3mapSkin/Misc/Extra  UI·게임 상수 원문과 구조화 JSON
  war3map.shd             768×768 정적 그림자 raw byte
  LoadingScreen.mdx       W3I가 참조한 로딩 모델 원본


11. 데이터 권위와 코치 입력 순서
-------------------------------------------------------------------------------

같은 값이 여러 곳에 있을 때 다음 순서를 따른다.

  1. JASS에서 실제 실행되는 배열·분기·대입·호출
  2. object 바이너리의 실제 override field
  3. WTS/UI 툴팁 표시
  4. 이름·키워드 기반 자동 추론

예외:

  - UI 조합 150개의 구조화된 목표·재료 원장은
    `01_오브젝트_전수/recipes_150.json`을 사용한다.
  - 라운드·항법·횟수·실제 사용 가능 여부는 JASS 조건을 덧붙인다.
  - 역할 수치는 unit→ability→callback/callsite를 연결해 확정한다.

추천 엔진에 바로 넣어도 되는 것

  - exact rawcode와 object field
  - recipes_150의 149개 완전 연결 행
  - 1개 미해소 재료를 수동 확인한 뒤의 전체 레시피
  - 01_round_waves의 확정 웨이브·보스·타이머
  - 02_rules_confirmed에서 confidence=확정 또는 표시+실행인 행

추가 검증 없이 넣으면 안 되는 것

  - JASS transform 후보 81
  - SaveInteger raw 관계 292
  - 이름 미해소 rawcode 222
  - 폼 미확정 281
  - 툴팁 키워드만으로 만든 역할


12. 아직 확정할 수 없는 데이터
-------------------------------------------------------------------------------

맵 보호·원본 부재 때문에 확정 불가능

  - 아카이브 전체 실제 파일명과 개수
  - 이름을 모르는 임포트 모델·텍스처·음성
  - GUI 트리거 원래 이름·폴더·주석·액션 구조
  - 표준 war3mapUnits.doo 원본
  - 에디터 region/camera/sound 원본

Warcraft 기본 데이터 상속 때문에 이 맵 파일만으로 불완전

  - object override에 기록되지 않은 모든 base object 최종값

정적 의미 연결이 덜 된 항목

  - UI 조합 재료 명칭 1건
  - 폼 의미 분류 281개
  - JASS rawcode 이름 222개
  - damage/CC callsite 중 유닛 소유자 자동 연결이 안 된 행
  - 55·60·65 보스의 개별 보상을 특정 지급문과 완전히 결합한 원장

이 항목들은 삭제하거나 추측값으로 채우지 않고 그대로 미확정 원장에 남겼다.


13. 파일 형식과 인코딩
-------------------------------------------------------------------------------

CSV/TSV
  - UTF-8 BOM
  - Windows 메모장과 Excel에서 한글 바로 표시
  - 첫 행은 컬럼명

JSON
  - UTF-8, BOM 없음
  - 한글을 `\uXXXX`로 바꾸지 않음
  - raw object modification은 type/level/dataPointer/value/endMarker 보존

CSV.GZ
  - 7-Zip 등으로 풀면 UTF-8 BOM CSV
  - 대용량 지형/pathing 표에만 사용

PNG
  - 원시 데이터를 대체하지 않는 시각 보조
  - +Y 북쪽이 위, 좌표와 범례 표시


14. 검증
-------------------------------------------------------------------------------

오브젝트

  - 7개 바이너리 parsedBytes == fileBytes
  - EOF 정확 일치
  - modification 필드 무손실 전수 재로딩
  - WTS 10,629개, TRIGSTR 미해소 0
  - 조합 목표 150/150, 재료 433건 중 432 연결·1 미해소

JASS

  - 라운드 65, 보스 8
  - rawcode 13,074회 / 고유 2,371
  - 함수 2,691
  - WTS STRING 0 포함 10,629
  - object 레시피와 ability 150/150·재료 433건 전수 일치
  - 자동검사 36개 통과, 실패 0

지도 구조

  - 원본 W3X SHA-256 전후 동일
  - W3I/W3E/WPM/DOO/MMP 완전 소비 또는 정확 행 수
  - pathing raw 589,824 byte
  - CSV/CSV.GZ BOM 확인
  - 자산 사본 해시 일치
  - 구조 자동검사 전부 통과

패키지 전체

  - `00_읽어보기/VALIDATION_REPORT.txt`에서 모든 JSON 파싱,
    CSV/TSV 컬럼 수, UTF-8 텍스트, 행 수 불변식, 파일 해시를 확인한다.
  - `00_읽어보기/FILE_MANIFEST_SHA256.tsv`에서 개별 파일 무결성을 확인한다.


15. 최종 결론
-------------------------------------------------------------------------------

이제 이 패키지는 "무엇을 뽑을 수 있는지"만 설명하는 보고서가 아니다.
2.312[R]에서 복구 가능한 object·문자열·조합·실행 규칙·지도 구조를 실제
전수 행으로 보존한 데이터 원장이다.

악몽 코치에 적용할 때 가장 중요한 원칙:

  1. `version=2.312R`로 2.305와 완전히 분리한다.
  2. JASS 실행 규칙을 툴팁보다 우선한다.
  3. 제작 가능·희귀 보호·리롤을 하나의 조합 원장으로 계산한다.
  4. 상위 제한과 리롤 횟수를 전역 상수가 아니라 항법·상태로 계산한다.
  5. 후보/미확정 행은 숨기지 말되 추천 점수에는 넣지 않는다.

원본 W3X는 수정하지 않았다.

===============================================================================
 끝
===============================================================================
