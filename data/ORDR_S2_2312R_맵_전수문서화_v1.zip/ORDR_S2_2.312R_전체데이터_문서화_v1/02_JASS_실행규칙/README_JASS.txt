﻿ORDR S2 2.312[R] JASS/WTS 완전판 정적 문서

원본
- /workspace/scratch/71bed8773174/map_analysis/extracted/war3map.j (88,361줄)
- /workspace/scratch/71bed8773174/map_analysis/extracted/war3map.wts (70,650줄)

재생성
  python3 generate_jass_docs.py

인코딩
- CSV: UTF-8 BOM(Windows 메모장/Excel 호환)
- TXT: UTF-8 BOM
- JSON: UTF-8, 한글 보존(ensure_ascii=false)

파일 설명
- 01_round_waves.csv/json/txt: 1~65 일반 qG와 보스 vG rawcode, 이름, 타이머, 근거줄.
- 02_rules_confirmed.csv/txt: 난이도·오로성·모드·항법의 확인 규칙. confidence가 '표시'이면 UI 문구이며 실행 수치로 단정하지 않습니다.
- 02_rule_source_blocks.txt: 난이도/오로성/항법 원문 블록. 난독화 변수와 raw 상수를 그대로 보존합니다.
- 03_gameplay_evidence.csv/txt: 보상·도박·리롤·변화·세라핌·보물·스토리·퀘스트·카운터·채팅명령 키워드 전수 원문 인덱스.
- 03_chat_commands.csv: Gyj 채팅 명령 등록과 callback 원기호.
- jass_recipe_rules.csv/json: WTS 조합 버튼 150개는 object/recipes_150.json과 전수 교차검증(재료433, rawcode 해소432/미해소1). 그 밖에 JASS 고유 명령/그린블러드/변환후보 107개와 불투명 SaveInteger raw 관계를 신뢰도별로 포함합니다.
- jass_ai_table_edges.csv: Ai hashtable parent/value 관계. 의미는 미확정이며 조합 재료로 간주 금지.
- jass_rawcode_relations.csv: 한 줄에 FourCC가 2개 이상인 SaveInteger 관계 전수. 업그레이드/변환 표가 포함되지만 테이블 의미는 난독화되어 미확정입니다.
- jass_transform_candidates.csv: CreateUnit과 Kill/Remove가 공존하는 함수 후보. 소환 스킬이 섞이므로 미확정.
- 04_rawcode_occurrences.csv: 모든 13,074개 JASS rawcode 출현 위치(줄/함수/원문).
- 04_rawcode_ledger.csv/json: 고유 rawcode 2,371개별 출현 줄·함수·WTS 해소 원장.
- 05_damage_cc_callsites.csv: 피해/CC/감속/스턴/능력추가 후보 호출 위치. 호출은 확정이나 특정 유닛 역할 귀속은 후보입니다.
- 05_callback_registrations.csv: h5J/H5o/fWo rawcode→callback symbol→원 함수 연결. damage/CC 표의 registered_owner 컬럼 근거입니다.
- jass_function_index.csv: 원 함수명, 줄 범위, 매개변수/return, 내부 JASS callee, rawcode 참조.
- jass_call_edges.csv: 알려진 JASS 함수 사이 caller→callee 정적 간선.
- 06_jass_strings.csv: JASS 문자열 리터럴 전수.
- 06_call_statistics.csv: `call name(...)` 호출명 빈도. defined_in_jass=N에는 Warcraft native와 외부 라이브러리가 함께 포함됩니다.
- 06_hex_constants.csv: 8자리 $HEX 상수 통계.
- 06_statistics_summary.json/txt: 원본 해시와 전체 개수.
- 07_confidence_ledger.csv/txt: 확정/표시/추론/미확정 구분과 사용 금지선.
- VALIDATION_JASS.txt: 생성 후 핵심 행 수·JSON 파싱·CSV BOM 검증 결과.

공통 컬럼 의미
- rawcode: Warcraft FourCC를 latin-1 4문자로 복원한 값.
- hex: 소스의 $XXXXXXXX 표현.
- source/source_lines/line: 1부터 시작하는 원본 줄 번호.
- confidence:
  · 확정 = 실행 배열/분기/대입/호출에서 직접 확인
  · 표시 = WTS 또는 UI 문구에만 존재
  · 표시+실행 = 문구와 실행 흔적이 모두 확인됨
  · 후보/미확정 = 의미 연결이 완전하지 않아 코치 규칙으로 하드코딩 금지

검증 원칙
- 난독화된 함수·변수는 이름을 추정 변경하지 않았습니다.
- WTS 수치와 JASS 실행 수치를 분리했습니다.
- 같은 함수에 CreateUnit/KillUnit이 있다는 이유만으로 조합식으로 단정하지 않습니다.
- 2.312[R]에는 Mj>=3, Mj>=4의 실제 트리플/콰트로 완료 코드가 있어 전역 '상위 최대2' 규칙은 사용할 수 없습니다.
