#!/usr/bin/env python3
"""Reproducible static documentation generator for ORDR war3map.j / war3map.wts.

No semantic renaming of obfuscated JASS symbols is performed.  Every derived row
retains source line(s), rawcodes and a confidence label.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parents[1] / "extracted"
JASS_PATH = SRC / "war3map.j"
WTS_PATH = SRC / "war3map.wts"
JASS = JASS_PATH.read_text(encoding="utf-8", errors="replace")
WTS = WTS_PATH.read_text(encoding="utf-8-sig", errors="replace")
JL = JASS.splitlines()
WL = WTS.splitlines()

COLOR_RE = re.compile(r"\|c[0-9A-Fa-f]{8}|\|r")
HEX_RE = re.compile(r"\$([0-9A-Fa-f]{8})")


def clean(s: str) -> str:
    return COLOR_RE.sub("", s).replace("\\n", " / ").replace("\r", " ").replace("\n", " / ").strip()


def raw_from_hex(h: str) -> str:
    try:
        return bytes.fromhex(h).decode("latin1")
    except Exception:
        return ""


def hex_from_raw(raw: str) -> str:
    return raw.encode("latin1", errors="replace").hex().upper()


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    if fields is None:
        fields = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def write_txt(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8-sig")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


# ---- WTS object blocks ----------------------------------------------------
wts_blocks = []
obj_re = re.compile(r"//\s*(유닛|능력|아이템|업그레이드|파괴 가능한 물체|장식물):\s*([A-Za-z0-9]{4})\s*\((.*?)\),\s*(.*)")
i = 0
while i < len(WL):
    sm = re.match(r"^STRING\s+(\d+)\s*$", WL[i])
    if not sm:
        i += 1
        continue
    start = i
    i += 1
    comments = []
    while i < len(WL) and WL[i].strip() != "{":
        if WL[i].startswith("//"):
            comments.append(WL[i])
        i += 1
    if i >= len(WL):
        break
    i += 1
    body_lines = []
    while i < len(WL) and WL[i].strip() != "}":
        body_lines.append(WL[i])
        i += 1
    i += 1
    comment = "\n".join(comments).strip()
    body = "\n".join(body_lines)
    obj = obj_re.search(comment)
    wts_blocks.append({"string_id": int(sm.group(1)), "line": start + 1,
                       "comment": comment, "body": body,
                       "kind": obj.group(1) if obj else "", "rawcode": obj.group(2) if obj else "",
                       "object_label": obj.group(3) if obj else "", "field": obj.group(4) if obj else ""})

objects_by_raw: dict[str, list[dict]] = defaultdict(list)
for b in wts_blocks:
    if b["rawcode"]:
        objects_by_raw[b["rawcode"]].append(b)


def object_names(raw: str) -> list[str]:
    vals = []
    for b in objects_by_raw.get(raw, []):
        if any(k in b["field"] for k in ("Name (", "Propernames (")):
            v = clean(b["body"])
            if v and v not in vals:
                vals.append(v)
    return vals


# ---- JASS function boundaries --------------------------------------------
func_starts = []
func_re = re.compile(r"^function\s+(\w+)\s+takes\s+(.*?)\s+returns\s+(\w+)", re.M)
for m in func_re.finditer(JASS):
    func_starts.append({
        "name": m.group(1), "takes": m.group(2), "returns": m.group(3),
        "start": JASS.count("\n", 0, m.start()) + 1, "char_start": m.start(),
    })
for i, f in enumerate(func_starts):
    end_char = func_starts[i + 1]["char_start"] if i + 1 < len(func_starts) else len(JASS)
    end_match = list(re.finditer(r"^endfunction\s*$", JASS[f["char_start"]:end_char], re.M))
    if end_match:
        f["char_end"] = f["char_start"] + end_match[-1].end()
        f["end"] = JASS.count("\n", 0, f["char_end"]) + 1
    else:
        f["char_end"] = end_char
        f["end"] = JASS.count("\n", 0, end_char) + 1
    f["body"] = JASS[f["char_start"]:f["char_end"]]

func_by_line = [None] * (len(JL) + 2)
for f in func_starts:
    for line in range(f["start"], min(f["end"], len(JL)) + 1):
        func_by_line[line] = f["name"]

known_funcs = {f["name"] for f in func_starts}


# ---- 01. Complete waves --------------------------------------------------
name_by_raw = {raw: (object_names(raw)[0] if object_names(raw) else "") for raw in objects_by_raw}
round_norm, round_boss = {}, {}
round_line = {}
for arr, target in (("qG", round_norm), ("vG", round_boss)):
    for m in re.finditer(rf"set {arr}\[(\d+)\]=\$([0-9A-Fa-f]{{8}})", JASS):
        rnd, raw = int(m.group(1)), raw_from_hex(m.group(2))
        target[rnd] = raw
        round_line[(arr, rnd)] = JASS.count("\n", 0, m.start()) + 1

waves = []
for rnd in range(1, 66):
    nr, br = round_norm.get(rnd, ""), round_boss.get(rnd, "")
    if rnd <= 50:
        timer = 60 if br else 35
        segment = "전반 1~50"
        timer_src = "18462-18474;82976-82980"
    else:
        timer = 32
        segment = "신세계 51~65"
        timer_src = "45179-45187;19327-19343"
    waves.append({
        "round": rnd, "segment": segment, "timer_seconds": timer,
        "normal_rawcode": nr, "normal_hex": hex_from_raw(nr) if nr else "",
        "normal_name": name_by_raw.get(nr, ""), "normal_source_line": round_line.get(("qG", rnd), ""),
        "boss_rawcode": br, "boss_hex": hex_from_raw(br) if br else "",
        "boss_name": name_by_raw.get(br, ""), "boss_source_line": round_line.get(("vG", rnd), ""),
        "timer_source_lines": timer_src, "confidence": "확정",
    })
write_csv(HERE / "01_round_waves.csv", waves)
write_json(HERE / "01_round_waves.json", waves)
wave_txt = ["ORDR S2 2.312[R] 1~65 라운드 웨이브/보스", ""]
for r in waves:
    units = []
    if r["normal_rawcode"]:
        units.append(f"일반 {r['normal_rawcode']} {r['normal_name']}")
    if r["boss_rawcode"]:
        units.append(f"보스 {r['boss_rawcode']} {r['boss_name']}")
    wave_txt.append(f"{r['round']:02d}라 | {r['timer_seconds']}초 | " + " / ".join(units))
write_txt(HERE / "01_round_waves.txt", "\n".join(wave_txt) + "\n")


# ---- 02. Curated confirmed/display rules --------------------------------
rules = []
def rule(cat, sub, name, value, confidence, src, note="", rawcode=""):
    rules.append({"category": cat, "subcategory": sub, "rule": name, "value": value,
                  "confidence": confidence, "source": src, "rawcode": rawcode, "note": note})

rule("난이도", "1", "쉬움", "보스 미처치 패배 없음; 스토리 체력 20% 감소; 라운드 적 체력 15% 감소; 41라 진입 클리어; 유닛카운트 100", "확정", "war3map.j:78613-78629")
rule("난이도", "2", "보통", "50라 센고쿠 처치 클리어; 유닛카운트 100", "확정", "war3map.j:78630-78643")
rule("난이도", "3", "어려움", "카운트80; 보스HP +40%; 적 이속 +30%; 35라까지 어인섬 미파괴 패배", "확정", "war3map.j:78644-78669")
rule("난이도", "4", "지옥", "카운트70; 적 마방 +5%; 보스HP +125%; 적 이속 +30%; 35라까지 드레스로자 미파괴 패배", "확정", "war3map.j:78670-78702")
rule("난이도", "5", "신", "카운트70→41라부터55; 적 마방 +5%; 보스HP +200%; 적 이속 +50%; 35라까지 홀케이크섬 미파괴 패배", "확정", "war3map.j:78703-78737;14379")
rule("난이도", "6", "악몽", "카운트70→41라부터50; 적 마방 +10%; 보스HP +200%; 적 이속 +50%; 35라까지 와노쿠니 미파괴 패배; 클리어 베리+1", "확정", "war3map.j:78738-78772;14382")
rule("오로성", "워큐리", "악몽 추가", "적 방어+15, 마방+15%, 보스HP+1500만; 악몽 공통 적HP+1000만/재생+50만", "확정", "war3map.j:9351-9381", rawcode="o02E")
rule("오로성", "새턴", "악몽 추가", "아군 공격-30%, 폭발형 피해-10%, 적 재생+30만; 악몽 공통 적HP+1000만/재생+50만", "확정", "war3map.j:9383-9411", rawcode="o031")
rule("오로성", "나스쥬로", "악몽 추가", "적 이속+15%, 아군 공속-15%, 라인HP+1500만; 악몽 공통 적HP+1000만/재생+50만", "확정", "war3map.j:9413-9435", rawcode="o032")
rule("모드", "변질", "상위 잠금", "상위테크 유닛 30% 조합 불가", "확정", "war3map.j:78781-78785;37327", rawcode="u007")
rule("모드", "이세계", "추가 유닛/도박", "이세계 유닛 추가 및 이세계 도박 활성", "확정", "war3map.j:78786-78794;37336", rawcode="u006")
rule("모드", "연구소", "상위 잠금 표시", "상위테크 유닛 30% 조합 불가로 표시", "표시", "war3map.j:37345", rawcode="u00D")
rule("항법", "연합세력", "기본", "전설·히든 이상 조합 시 랜덤위습1", "표시", "war3map.j:64711-64715")
rule("항법", "연합세력/일석이조", "효과", "항법 기본효과 발동 시 랜덤위습 추가", "표시", "war3map.j:64061-64065")
rule("항법", "연합세력/긴급소집", "효과", "특별 선택 와일드카드3; 기본효과 비활성", "표시", "war3map.j:64096-64100")
rule("항법", "연합세력/특성공학", "효과", "특성포인트1·변화횟수1 생산; 도움소 선택위습 획득 불가", "표시", "war3map.j:64131-64135")
rule("항법", "패왕의길", "기본/제한", "라인 이속-7%; 보스처치 목재+2; 최상위 1기만 조합", "확정", "war3map.j:64743-64749;40483-40491;79933-79941;26768-26776")
rule("항법", "패왕의길/계엄령", "효과/제한", "클리어 베리2배; 최상위(초월·불멸·영원·제한·신비) 조합 불가", "표시+실행", "war3map.j:64180-64184;62804")
rule("항법", "패왕의길/바운티헌터", "효과", "라인몹 처치 시 낮은 확률 보물상자", "표시", "war3map.j:64215-64219")
rule("항법", "패왕의길/로얄로더", "효과", "최상위에 공속25%·공격력25000; 공격시8% 400범위 고정255000", "표시+실행", "war3map.j:64250-64254;80150-80164")
rule("항법", "도박광", "기본", "희귀 리롤 +1", "표시", "war3map.j:64775-64781")
rule("항법", "도박광/카지노", "효과/제한", "고급 성공은 희귀 확정; 이세계 1% 랜덤전용; 하급·중급 비활성; 코드상 리롤+1", "확정", "war3map.j:64299-64303;32723-32741")
rule("항법", "도박광/리스크헷지", "효과", "고급 실패 토큰1·목재1; 희귀리롤 목재0; 코드상 리롤+2; 이세계 실패확률+11%", "확정", "war3map.j:64334-64338;32742-32758;41709-41727")
rule("항법", "도박광/연속베팅", "효과/제한", "중급 2회 랜덤위습, 4회 선택위습, 6회 랜덤위습+목재, 12회 해적선; 기본효과·고급도박 비활성", "표시+실행", "war3map.j:64369-64373;65885-65916")
rule("항법", "최고의도움", "기본", "도움소 마나회복 초당 +0.7", "표시", "war3map.j:64807-64811")
rule("항법", "최고의도움/최대출력", "효과", "버스터콜·해루석·대지진·낙뢰·독약 강화; 마나포션 추가", "표시", "war3map.j:64418-64422")
rule("항법", "최고의도움/연금술", "효과", "도움소 연금술 추가; 마나 소비 유닛 분해", "표시", "war3map.j:64453-64457")
rule("항법", "최고의도움/역발상", "효과/제한", "레일리 희귀 즉시+유니크 발굴1; 기본효과 비활성; 마나소모150 이하 스킬만", "표시", "war3map.j:64488-64492")
rule("항법", "랜덤선택", "효과", "무작위 항법 선택; 랜덤위습1 추가", "표시", "war3map.j:64535-64541;64839-64843")
rule("제한", "리롤", "초기/비용", "희귀 리롤 초기2; 1회당 목재2(리스크헷지0); 같은 rawcode 재추첨", "확정", "war3map.j:48457-48466;41700-41743")
rule("제한", "변화", "초기/비용", "초기2회; 변화마다 목재10+횟수1; 시전10초", "확정", "war3map.j:48457-48466;16507-16519|war3map.wts:38280-38480")
rule("제한", "세라핌", "그린블러드", "전설/히든에 1회; 특정 유닛 세라핌 변환", "확정", "war3map.j:24904-24961|war3map.wts:20588-20596")
rule("제한", "최상위 총량", "전역 최대2 근거 없음", "Mj>=3 트리플, Mj>=4 콰트로가 실제 완료됨", "확정", "war3map.j:78178-78196;24342-24364", note="패왕의길만 별도 1기 제한")
rule("카운터", "152", "진화체 경험치", "라인몹 처치 152회에서 진화체 활성; 희귀 보상 아님", "확정", "war3map.j:24589-24612;62568-62590;80418-80437")

write_csv(HERE / "02_rules_confirmed.csv", rules)
write_txt(HERE / "02_rules_confirmed.txt", "\n".join(
    ["난이도·오로성·모드·항법 확인 규칙", ""] +
    [f"[{r['confidence']}] {r['category']}/{r['subcategory']} {r['rule']}\n  {r['value']}\n  근거: {r['source']}" for r in rules]
) + "\n")

source_blocks = []
for title, a, b in [("난이도 1~6/모드 실행부", 78613, 78795), ("오로성 난이도 효과", 9345, 9438),
                    ("항법 상세 UI 문자열", 63980, 64550), ("항법 요약 UI", 64690, 64850)]:
    source_blocks += [f"===== {title} ({a}-{b}) ====="] + [f"{i}: {JL[i-1]}" for i in range(a, b+1)] + [""]
write_txt(HERE / "02_rule_source_blocks.txt", "\n".join(source_blocks))


# ---- 03. Gameplay keyword evidence and recipes ---------------------------
keyword_groups = {
    "보상": ["보상", "골드", "목재", "위습", "베리"],
    "도박": ["도박", "행운의 토큰"],
    "리롤": ["리롤"],
    "변화": ["변화가능", "[변화]", "변화 유닛"],
    "세라핌": ["세라핌", "그린블러드"],
    "보물": ["보물", "발굴"],
    "스토리": ["스토리", "기여도"],
    "퀘스트": ["퀘스트", "미션"],
    "카운터": ["카운트", "152", "횟수", "스택"],
    "채팅명령": ["명령어", "-점수판", "-score", "-리롤", "-reroll"],
}
evidence = []
for i, line in enumerate(JL, 1):
    cats = [cat for cat, terms in keyword_groups.items() if any(t in line for t in terms)]
    if cats:
        evidence.append({"source_file": "war3map.j", "line": i, "function": func_by_line[i] or "",
                         "categories": ";".join(cats), "rawcodes": ";".join(raw_from_hex(h) for h in HEX_RE.findall(line)),
                         "text": line.strip(), "confidence": "원문"})
for b in wts_blocks:
    blob = b["comment"] + "\n" + b["body"]
    cats = [cat for cat, terms in keyword_groups.items() if any(t in blob for t in terms)]
    if cats:
        evidence.append({"source_file": "war3map.wts", "line": b["line"], "function": "",
                         "categories": ";".join(cats), "rawcodes": b["rawcode"],
                         "text": clean(b["body"]).replace("\n", " / "), "confidence": "표시"})
write_csv(HERE / "03_gameplay_evidence.csv", evidence)
write_txt(HERE / "03_gameplay_evidence.txt", "\n".join(
    f"{r['source_file']}:{r['line']} [{r['categories']}] {r['text']}" for r in evidence
) + "\n")

# 150 UI recipe buttons, structured without inventing quantities.
by_obj = defaultdict(list)
for b in wts_blocks:
    if b["rawcode"]:
        by_obj[(b["kind"], b["rawcode"])].append(b)

GRADE_WORDS = "흔함|안흔함|특별|희귀|전설|히든|변화|초월|불멸|영원|제한|세라핌|왜곡|신비|오로성|랜덤전용"
unit_name_to_raw = defaultdict(list)
for raw, entries in objects_by_raw.items():
    if not any(b["kind"] == "유닛" for b in entries):
        continue
    for b in entries:
        if b["kind"] != "유닛" or not any(k in b["field"] for k in ("Name (", "Propernames (")):
            continue
        full = clean(b["body"]).strip()
        keys = {full, re.sub(rf"\s*-\s*(?:{GRADE_WORDS}).*$", "", full).strip()}
        for key in keys:
            if key and raw not in unit_name_to_raw[key]:
                unit_name_to_raw[key].append(raw)

def label_raw_candidates(label: str) -> list[str]:
    text = clean(label).strip("▶　 ")
    base = re.sub(rf"\s*-\s*(?:{GRADE_WORDS}).*$", "", text).strip()
    out = list(unit_name_to_raw.get(text, []))
    for raw in unit_name_to_raw.get(base, []):
        if raw not in out:
            out.append(raw)
    return out

def grade_hint(label: str) -> str:
    m = re.search(rf"(?:^|\s|-)(?:({GRADE_WORDS}))(?:\s|$|\))", clean(label))
    return m.group(1) if m else ""

recipes = []
for (kind, ability_raw), entries in by_obj.items():
    if kind != "능력":
        continue
    tips = [x for x in entries if "Tip (" in x["field"] and "조합" in x["body"]]
    ubers = [x for x in entries if "Ubertip (" in x["field"]]
    if not tips or not ubers:
        continue
    u = ubers[0]
    parts = [clean(x.strip(" \t▶　")) for x in u["body"].splitlines() if clean(x.strip(" \t▶　"))]
    target = parts[0] if parts else ""
    ingredients, gold, lumber, round_limit, other = [], "", "", "", []
    for p in parts[1:]:
        if "골드" in p: gold = p
        elif "목재" in p: lumber = p
        elif "라운드" in p and ("까지" in p or "부터" in p): round_limit = p
        elif any(k in p for k in ("위습", "유닛", "해적선", "희귀", "전설", "히든", "특별", "안흔함", "흔함", "제한", "불멸", "영원", "초월", "왜곡", "신비", "랜덤전용", "변화", "아이템", "토큰")):
            ingredients.append(p)
        else: other.append(p)
    target_raws = label_raw_candidates(target)
    ingredient_map = []
    for ing in ingredients:
        qtym = re.search(r"(?:x|×|\*)\s*(\d+)|(\d+)\s*기", ing, re.I)
        qty = next((g for g in qtym.groups() if g), "1") if qtym else "1"
        raws = label_raw_candidates(ing)
        ingredient_map.append(f"{ing}=>{','.join(raws) if raws else '?'}:{qty}")
    recipes.append({"record_type": "WTS_UI_RECIPE", "ability_rawcode": ability_raw,
                    "category_hint": grade_hint(target), "target": target,
                    "target_rawcode_candidates": ";".join(target_raws), "ingredients_text": " | ".join(ingredients),
                    "ingredient_rawcodes_qty": " | ".join(ingredient_map), "gold": gold, "lumber": lumber,
                    "round_rule": round_limit, "navigation_rule": "", "use_limit": "",
                    "command": "", "source_file": "war3map.wts", "source_lines": f"{tips[0]['line']};{u['line']}",
                    "condition_original": clean(u["body"]).replace("\n", " / "), "confidence": "표시"})

# Chat combination command aliases and target unit rawcodes from Ai SaveStr tables.
alias_parent = {}
for i, line in enumerate(JL, 1):
    m = re.search(r'call SaveStr\(Ai,\$([0-9A-Fa-f]{8}),[^,]+,"([^"]+)"\)', line)
    if m:
        alias_parent[m.group(2)] = (raw_from_hex(m.group(1)), i)
chat_rows = []
for i, line in enumerate(JL, 1):
    m = re.search(r'call Gyj\("([^"]+)",true,(\w+)\)', line)
    if not m:
        continue
    alias, callback = m.groups()
    parent, pline = alias_parent.get(alias, ("", ""))
    row = {"command": alias, "callback_symbol": callback, "target_rawcode": parent,
           "target_names": " | ".join(object_names(parent)), "registration_line": i,
           "alias_table_line": pline, "confidence": "확정 등록"}
    chat_rows.append(row)
    if alias.endswith("조합"):
        recipes.append({"record_type": "JASS_CHAT_RECIPE_COMMAND", "ability_rawcode": "",
                        "category_hint": grade_hint(" | ".join(object_names(parent))),
                        "target": " | ".join(object_names(parent)), "target_rawcode_candidates": parent,
                        "ingredients_text": "", "ingredient_rawcodes_qty": "미확정", "gold": "", "lumber": "",
                        "round_rule": "", "navigation_rule": "", "use_limit": "", "command": alias,
                        "source_file": "war3map.j", "source_lines": f"{pline};{i}",
                        "condition_original": line.strip(), "confidence": "명령 등록 확정/재료 미확정"})
write_csv(HERE / "03_chat_commands.csv", chat_rows)

# Greenblood source->target transformations from OFS are explicit JASS rules.
ofs = next(f for f in func_starts if f["name"] == "OFS")
active_src = None
for off, line in enumerate(ofs["body"].splitlines(), ofs["start"]):
    msrc = re.search(r"(?:if|elseif) \$([0-9A-Fa-f]{8})==GetUnitTypeId\(QFS\) then", line)
    if msrc:
        active_src = raw_from_hex(msrc.group(1))
    mout = re.search(r"set tFS=CreateUnitAtLoc\([^,]+,\$([0-9A-Fa-f]{8}),", line)
    if active_src and mout:
        target = raw_from_hex(mout.group(1))
        recipes.append({"record_type": "JASS_GREENBLOOD_TRANSFORM", "ability_rawcode": "A13A",
                        "category_hint": "세라핌", "target": " | ".join(object_names(target)), "target_rawcode_candidates": target,
                        "ingredients_text": "대상 " + " | ".join(object_names(active_src)),
                        "ingredient_rawcodes_qty": f"{active_src}:1", "gold": "", "lumber": "",
                        "round_rule": "", "navigation_rule": "", "use_limit": "1회",
                        "command": "그린블러드", "source_file": "war3map.j", "source_lines": str(off),
                        "condition_original": line.strip(), "confidence": "확정"})
        active_src = None

# Opaque Ai parent->ability relations: preserve, never label as ingredients.
ai_edges = []
for i in range(len(JL) - 2):
    m = re.search(r"set (\w+)=LoadInteger\(Ai,\$([0-9A-Fa-f]{8}),-1\)", JL[i])
    if not m:
        continue
    var, ph = m.groups()
    for j in range(i + 1, min(i + 4, len(JL))):
        x = re.search(rf"call SaveInteger\(Ai,\${ph},{var},\$([0-9A-Fa-f]{{8}})\)", JL[j])
        if x:
            p, v = raw_from_hex(ph), raw_from_hex(x.group(1))
            ai_edges.append({"parent_rawcode": p, "parent_names": " | ".join(object_names(p)),
                             "value_rawcode": v, "value_names": " | ".join(object_names(v)),
                             "source_lines": f"{i+1}-{j+1}", "relation": "Ai hashtable opaque relation",
                             "confidence": "관계 확정/의미 미확정"})
            break
write_csv(HERE / "jass_ai_table_edges.csv", ai_edges)

# Candidate transformation/crafting functions: CreateUnit plus Kill/Remove in same function.
transform_candidates = []
for f in func_starts:
    body = f["body"]
    if ("CreateUnit" not in body) or not any(k in body for k in ("KillUnit", "RemoveUnit", "ShowUnit")):
        continue
    refs = [raw_from_hex(h) for h in HEX_RE.findall(body)]
    if len(set(refs)) < 2:
        continue
    transform_candidates.append({"function": f["name"], "start_line": f["start"], "end_line": f["end"],
                                 "rawcode_refs": ";".join(dict.fromkeys(refs)),
                                 "create_count": body.count("CreateUnit"), "kill_count": body.count("KillUnit"),
                                 "remove_count": body.count("RemoveUnit"),
                                 "confidence": "변환/소환 후보; 의미 미확정"})
    condition_lines = []
    for line in body.splitlines():
        if any(k in line for k in ("if ", "elseif ", "CreateUnit", "KillUnit", "RemoveUnit", "ShowUnit", "GetUnitTypeId")):
            condition_lines.append(line.strip())
    recipes.append({"record_type": "JASS_CREATE_KILL_CANDIDATE", "ability_rawcode": "",
                    "category_hint": "미확정", "target": "", "target_rawcode_candidates": ";".join(dict.fromkeys(refs)),
                    "ingredients_text": "", "ingredient_rawcodes_qty": "미확정", "gold": "", "lumber": "",
                    "round_rule": "", "navigation_rule": "", "use_limit": "", "command": "",
                    "source_file": "war3map.j", "source_lines": f"{f['start']}-{f['end']}",
                    "condition_original": " || ".join(condition_lines),
                    "confidence": "변환/조합/소환 후보; 의미 미확정"})
write_csv(HERE / "jass_transform_candidates.csv", transform_candidates)

# Every SaveInteger call containing at least two FourCC values.  Several of
# these tables are upgrade/transform maps, but table semantics are obfuscated;
# the relation is preserved verbatim and deliberately marked opaque.
raw_relations = []
for i, line in enumerate(JL, 1):
    m = re.search(r"call SaveInteger\((\w+),(.+)\)", line)
    if not m:
        continue
    hs = HEX_RE.findall(m.group(2))
    if len(hs) < 2:
        continue
    raws = [raw_from_hex(h) for h in hs]
    source_raw, value_raw = raws[0], raws[-1]
    rr = {"hashtable_symbol": m.group(1), "source_rawcode": source_raw,
          "source_names": " | ".join(object_names(source_raw)),
          "value_rawcode": value_raw, "value_names": " | ".join(object_names(value_raw)),
          "all_rawcodes": ";".join(raws), "line": i, "function": func_by_line[i] or "",
          "source_text": line.strip(), "confidence": "관계 확정/테이블 의미 미확정"}
    raw_relations.append(rr)
    recipes.append({"record_type": "JASS_SAVEINTEGER_RAW_RELATION", "ability_rawcode": "",
                    "category_hint": grade_hint(" | ".join(object_names(value_raw))),
                    "target": " | ".join(object_names(value_raw)), "target_rawcode_candidates": value_raw,
                    "ingredients_text": "source/parent " + " | ".join(object_names(source_raw)),
                    "ingredient_rawcodes_qty": f"{source_raw}:관계", "gold": "", "lumber": "",
                    "round_rule": "", "navigation_rule": "", "use_limit": "", "command": "",
                    "source_file": "war3map.j", "source_lines": str(i),
                    "condition_original": line.strip(), "confidence": "raw 관계 확정/조합 의미 미확정"})
write_csv(HERE / "jass_rawcode_relations.csv", raw_relations)

# Cross-check all 150 WTS recipes against the independently parsed w3a object
# ledger.  Object rows supply exact numeric resources and rawcode candidates;
# WTS source lines remain the human-readable evidence.
OBJECT_RECIPES_PATH = HERE.parent / "object" / "recipes_150.json"
object_recipe_rows = json.loads(OBJECT_RECIPES_PATH.read_text(encoding="utf-8"))
object_recipe_by_ability = {r["abilityRawcode"]: r for r in object_recipe_rows}
for row in recipes:
    row.setdefault("items", "")
    row.setdefault("tokens", "")
    row.setdefault("other_requirements", "")
    row.setdefault("object_crosscheck", "")
    if row["record_type"] != "WTS_UI_RECIPE":
        continue
    obj = object_recipe_by_ability.get(row["ability_rawcode"])
    if not obj:
        row["object_crosscheck"] = "MISSING"
        continue
    row["category_hint"] = obj.get("targetGrade") or row["category_hint"]
    row["target"] = obj.get("target") or row["target"]
    row["target_rawcode_candidates"] = ";".join(obj.get("targetRawcodes", []))
    row["ingredients_text"] = " | ".join(
        f"{m['name']} x{m.get('quantity', 1)}" for m in obj.get("materials", []))
    row["ingredient_rawcodes_qty"] = " | ".join(
        f"{m['name']}=>{','.join(m.get('rawcodes', [])) if m.get('rawcodes') else '?'}:{m.get('quantity', 1)}"
        for m in obj.get("materials", []))
    row["gold"] = str(obj.get("gold", 0))
    row["lumber"] = str(obj.get("wood", 0))
    row["items"] = " | ".join(obj.get("items", []))
    row["tokens"] = str(obj.get("tokens", 0))
    row["other_requirements"] = " | ".join(obj.get("otherRequirements", []))
    lo, hi = obj.get("roundMin"), obj.get("roundMax")
    row["round_rule"] = f"min={lo if lo is not None else ''};max={hi if hi is not None else ''}"
    row["object_crosscheck"] = "MATCHED"
    row["confidence"] = "표시+w3a object 교차검증"

write_csv(HERE / "jass_recipe_rules.csv", recipes)
write_json(HERE / "jass_recipe_rules.json", recipes)


# ---- 04. Rawcode occurrence / cross-reference ledger ---------------------
occurrences = []
occ_by_hex = defaultdict(list)
for i, line in enumerate(JL, 1):
    for m in HEX_RE.finditer(line):
        h, raw = m.group(1).upper(), raw_from_hex(m.group(1))
        row = {"hex": h, "rawcode": raw, "line": i, "function": func_by_line[i] or "",
               "column": m.start() + 1, "source_text": line.strip()}
        occurrences.append(row)
        occ_by_hex[h].append(row)
write_csv(HERE / "04_rawcode_occurrences.csv", occurrences)

ledger = []
for h in sorted(occ_by_hex):
    raw = raw_from_hex(h)
    obs = objects_by_raw.get(raw, [])
    desc = []
    for b in obs:
        if any(k in b["field"] for k in ("Name (", "Propernames (")):
            d = f"{b['kind']}:{clean(b['body'])}"
            if d not in desc: desc.append(d)
    lines = [x["line"] for x in occ_by_hex[h]]
    funcs = list(dict.fromkeys(x["function"] for x in occ_by_hex[h] if x["function"]))
    ledger.append({"hex": h, "rawcode": raw, "resolved": "Y" if obs else "N",
                   "object_descriptions": " | ".join(desc), "occurrence_count": len(lines),
                   "jass_lines": ";".join(map(str, lines)), "functions": ";".join(funcs),
                   "wts_string_ids": ";".join(str(b["string_id"]) for b in obs),
                   "wts_lines": ";".join(str(b["line"]) for b in obs)})
write_csv(HERE / "04_rawcode_ledger.csv", ledger)
write_json(HERE / "04_rawcode_ledger.json", ledger)


# ---- 05. Damage / crowd-control candidate callsites ----------------------
# Recover callback symbols without renaming them.  The obfuscator stores many
# callbacks as `set symbol=function originalName`, then registers the symbol
# against a unit/ability rawcode with h5J/H5o/fWo.
code_symbol_to_function = {}
for i, line in enumerate(JL, 1):
    m = re.search(r"set (\w+)=function (\w+)", line)
    if m:
        code_symbol_to_function[m.group(1)] = (m.group(2), i)
registered_by_function = defaultdict(list)
registration_rows = []
reg_patterns = [
    ("h5J", re.compile(r"call h5J\(\$([0-9A-Fa-f]{8}),(\w+)\)")),
    ("H5o", re.compile(r"call H5o\(\$([0-9A-Fa-f]{8}),(\w+)\)")),
    ("fWo", re.compile(r"call fWo\([^,]+,\$([0-9A-Fa-f]{8}),(\w+)\)")),
]
for i, line in enumerate(JL, 1):
    for api, pat in reg_patterns:
        m = pat.search(line)
        if not m:
            continue
        raw, sym = raw_from_hex(m.group(1)), m.group(2)
        func, assign_line = code_symbol_to_function.get(sym, ("", ""))
        registration_rows.append({"registration_api": api, "rawcode": raw,
                                  "object_names": " | ".join(object_names(raw)),
                                  "callback_symbol": sym, "function": func,
                                  "symbol_assignment_line": assign_line, "registration_line": i})
        if func and raw not in registered_by_function[func]:
            registered_by_function[func].append(raw)
write_csv(HERE / "05_callback_registrations.csv", registration_rows)

callsite_patterns = {
    "damage_fJj": re.compile(r"\bfJj\("),
    "damage_point": re.compile(r"\bUnitDamagePoint(?:Loc)?\("),
    "damage_target": re.compile(r"\bUnitDamageTarget\("),
    "cc_TES": re.compile(r"\bTES\("),
    "cc_order_slow": re.compile(r"IssueTargetOrder(?:ById)?\([^\n]*(?:\"slow\"|OrderId\(\"slow\"\))"),
    "cc_order_stun": re.compile(r"IssueTargetOrder(?:ById)?\([^\n]*(?:\"firebolt\"|OrderId\(\"firebolt\"\))"),
    "movement": re.compile(r"\bSetUnitMoveSpeed\("),
    "ability_add": re.compile(r"\bUnitAddAbility\("),
}
callsites = []
for i, line in enumerate(JL, 1):
    cats = [k for k, p in callsite_patterns.items() if p.search(line)]
    if not cats: continue
    refs = [raw_from_hex(h) for h in HEX_RE.findall(line)]
    owners = registered_by_function.get(func_by_line[i] or "", [])
    callsites.append({"line": i, "function": func_by_line[i] or "", "categories": ";".join(cats),
                      "registered_owner_rawcodes": ";".join(owners),
                      "registered_owner_names": " | ".join(" / ".join(object_names(x)) for x in owners),
                      "rawcode_refs_same_line": ";".join(refs), "source_text": line.strip(),
                      "confidence": "호출 위치 확정/유닛 역할 귀속 후보"})
write_csv(HERE / "05_damage_cc_callsites.csv", callsites)


# ---- 06. Functions, call graph, strings, constants, call stats -----------
function_rows = []
call_edges = []
native_counter, native_lines = Counter(), defaultdict(list)
for f in func_starts:
    body = f["body"]
    refs = list(dict.fromkeys(raw_from_hex(h) for h in HEX_RE.findall(body)))
    calls = re.findall(r"\bcall\s+(\w+)\s*\(", body)
    direct = re.findall(r"(?<!function\s)(?<!call\s)\b(\w+)\s*\(", body)
    all_calls = calls + direct
    callees = []
    for c in all_calls:
        if c in known_funcs and c != f["name"] and c not in callees:
            callees.append(c)
    for c in callees:
        call_edges.append({"caller": f["name"], "callee": c, "caller_start_line": f["start"]})
    external_calls = Counter(c for c in calls if c not in known_funcs)
    for off, line in enumerate(body.splitlines(), f["start"]):
        for c in re.findall(r"\bcall\s+(\w+)\s*\(", line):
            native_counter[c] += 1
            native_lines[c].append(off)
    function_rows.append({"function": f["name"], "start_line": f["start"], "end_line": f["end"],
                          "line_count": f["end"] - f["start"] + 1, "parameters": f["takes"],
                          "return_type": f["returns"], "call_summary": ";".join(callees),
                          "native_external_call_summary": ";".join(f"{n}:{c}" for n, c in external_calls.most_common()),
                          "rawcode_refs": ";".join(refs), "rawcode_ref_count": len(refs)})
write_csv(HERE / "jass_function_index.csv", function_rows)
write_csv(HERE / "jass_call_edges.csv", call_edges)

string_rows = []
str_re = re.compile(r'"((?:\\.|[^"\\])*)"')
for i, line in enumerate(JL, 1):
    for m in str_re.finditer(line):
        string_rows.append({"line": i, "function": func_by_line[i] or "", "column": m.start()+1,
                            "length": len(m.group(1)), "value": m.group(1)})
write_csv(HERE / "06_jass_strings.csv", string_rows)

native_rows = [{"call_name": n, "count": c, "first_line": min(native_lines[n]),
                "last_line": max(native_lines[n]), "defined_in_jass": "Y" if n in known_funcs else "N"}
               for n, c in native_counter.most_common()]
write_csv(HERE / "06_call_statistics.csv", native_rows)

constant_rows = []
for h, obs in sorted(occ_by_hex.items()):
    raw = raw_from_hex(h)
    constant_rows.append({"hex": h, "rawcode": raw, "count": len(obs),
                          "resolved": "Y" if raw in objects_by_raw else "N",
                          "first_line": obs[0]["line"], "last_line": obs[-1]["line"]})
write_csv(HERE / "06_hex_constants.csv", constant_rows)

summary = {
    "source": {"war3map.j": {"lines": len(JL), "sha256": sha256(JASS_PATH)},
               "war3map.wts": {"lines": len(WL), "sha256": sha256(WTS_PATH)}},
    "counts": {"functions": len(func_starts), "call_edges": len(call_edges),
               "jass_string_literals": len(string_rows), "call_names": len(native_rows),
               "rawcode_occurrences": len(occurrences), "unique_rawcodes": len(ledger),
               "resolved_rawcodes": sum(r["resolved"] == "Y" for r in ledger),
               "unresolved_rawcodes": sum(r["resolved"] == "N" for r in ledger),
               "wts_blocks": len(wts_blocks), "recipe_ui_rows": sum(r["record_type"] == "WTS_UI_RECIPE" for r in recipes),
               "recipe_total_rows": len(recipes), "damage_cc_callsites": len(callsites),
               "callback_registrations": len(registration_rows),
               "damage_cc_callsites_with_registered_owner": sum(bool(r["registered_owner_rawcodes"]) for r in callsites),
               "gameplay_evidence_rows": len(evidence)},
    "wts_kind_counts": Counter(b["kind"] for b in wts_blocks if b["kind"]),
}
summary["wts_kind_counts"] = dict(summary["wts_kind_counts"])
write_json(HERE / "06_statistics_summary.json", summary)
write_txt(HERE / "06_statistics_summary.txt", json.dumps(summary, ensure_ascii=False, indent=2) + "\n")


# ---- 07. Confidence / uncertainty ledger --------------------------------
confidence = [
    {"topic": "라운드 qG/vG rawcode", "status": "확정", "basis": "JASS 배열 직접 대입", "source": "war3map.j:77244-77311", "limitation": "소환 수량/HP는 별도 시스템"},
    {"topic": "라운드 타이머", "status": "확정", "basis": "TimerStart와 oJ 대입", "source": "war3map.j:18462-18474;45179-45187;19327-19343;82979", "limitation": "외부 패치/런타임 치트 제외"},
    {"topic": "난이도 표시 수치", "status": "확정", "basis": "IS 분기에서 표시와 기술연구 동시 실행", "source": "war3map.j:78613-78773", "limitation": "R00x 연구 raw 수치의 내부 곱연산은 객체 데이터 필요"},
    {"topic": "WTS 조합식 150개", "status": "표시", "basis": "조합 버튼 Ubertip", "source": "war3map.wts", "limitation": "표시와 실행 조건 불일치 가능; 재료 rawcode/수량은 객체/트리거 교차검증 필요"},
    {"topic": "UI 조합 150개 object 대조", "status": "교차검증", "basis": "ability rawcode 150/150 일치; 재료433 중 rawcode432 해소", "source": "full_docs/object/recipes_150.json + war3map.wts", "limitation": "A19T 에이스-왜곡 재료 rawcode 1건 미해소"},
    {"topic": "채팅 조합 명령 22개", "status": "확정 등록", "basis": "Gyj 등록", "source": "war3map.j:85638-85722", "limitation": "콜백 내부 재료 검사는 난독화"},
    {"topic": "Ai hashtable edge", "status": "관계 확정/의미 미확정", "basis": "SaveInteger(Ai, parent, index, value)", "source": "jass_ai_table_edges.csv", "limitation": "재료가 아니라 능력/명령 연결일 가능성이 높아 ingredient로 사용 금지"},
    {"topic": "SaveInteger raw 관계 292개", "status": "관계 확정/의미 미확정", "basis": "동일 호출문에 FourCC 2개 이상", "source": "jass_rawcode_relations.csv", "limitation": "s 테이블27/Ai 테이블265; 업그레이드·능력 연결을 재료로 단정 금지"},
    {"topic": "변환 후보 함수", "status": "미확정 후보", "basis": "같은 함수에 CreateUnit + Kill/Remove", "source": "jass_transform_candidates.csv", "limitation": "소환 스킬도 다수 포함"},
    {"topic": "피해/CC callsite", "status": "호출 확정/귀속 후보", "basis": "JASS 호출문", "source": "05_damage_cc_callsites.csv", "limitation": "난독화된 콜백 등록 및 유닛 능력 연결 필요"},
    {"topic": "최상위 전역 최대2", "status": "반박", "basis": "Mj>=3/4 실제 퀘스트 완료", "source": "war3map.j:78178-78196;24342-24364", "limitation": "패왕의길만 1기 제한"},
    {"topic": "초월 전역 1기", "status": "미확정", "basis": "직접 제한문/카운터 의미를 찾지 못함", "source": "war3map.j/war3map.wts 전수 검색", "limitation": "하드코딩 금지"},
    {"topic": "55/60/65 보스 개별 보상", "status": "미확정", "basis": "vG는 확정이나 보상 함수와 rawcode 직접 연결 불충분", "source": "war3map.j", "limitation": "실행 이벤트 등록 추적 필요"},
    {"topic": "등급별 유닛 수", "status": "표시 후보", "basis": "WTS 이름 문자열", "source": "war3map.wts", "limitation": "더미/소환/분신 중복 포함"},
]
write_csv(HERE / "07_confidence_ledger.csv", confidence)
write_txt(HERE / "07_confidence_ledger.txt", "\n".join(
    f"[{r['status']}] {r['topic']}\n  근거: {r['basis']} / {r['source']}\n  한계: {r['limitation']}" for r in confidence
) + "\n")


# ---- README and manifest -------------------------------------------------
readme = f"""ORDR S2 2.312[R] JASS/WTS 완전판 정적 문서

원본
- {JASS_PATH} ({len(JL):,}줄)
- {WTS_PATH} ({len(WL):,}줄)

재생성
  python3 generate_jass_docs.py

인코딩
- CSV: UTF-8 BOM(Windows 메모장/Excel 호환)
- TXT: UTF-8 BOM
- JSON: UTF-8, 한글 보존(ensure_ascii=false)

파일 설명
- 01_round_waves.csv/json/txt: 1~65 일반 qG와 보스 vG rawcode, 이름, 타이머, 근거줄.
- 02_rules_confirmed.csv/txt: 난이도·오로성·모드·항법의 확인 규칙. confidence가 '표시'이면 UI 문구이며 실행 수치로 단정하지 않습니다.
- 02_rule_source_blocks.txt: 난이도/오로성/항법 원문 블록. 난독화 변수와 raw 상수를 그대로 보존합니다.
- 03_gameplay_evidence.csv/txt: 보상·도박·리롤·변화·세라핌·보물·스토리·퀘스트·카운터·채팅명령 키워드 전수 원문 인덱스.
- 03_chat_commands.csv: Gyj 채팅 명령 등록과 callback 원기호.
- jass_recipe_rules.csv/json: WTS 조합 버튼 150개는 object/recipes_150.json과 전수 교차검증(재료433, rawcode 해소432/미해소1). 그 밖에 JASS 고유 명령/그린블러드/변환후보 107개와 불투명 SaveInteger raw 관계를 신뢰도별로 포함합니다.
- jass_ai_table_edges.csv: Ai hashtable parent/value 관계. 의미는 미확정이며 조합 재료로 간주 금지.
- jass_rawcode_relations.csv: 한 줄에 FourCC가 2개 이상인 SaveInteger 관계 전수. 업그레이드/변환 표가 포함되지만 테이블 의미는 난독화되어 미확정입니다.
- jass_transform_candidates.csv: CreateUnit과 Kill/Remove가 공존하는 함수 후보. 소환 스킬이 섞이므로 미확정.
- 04_rawcode_occurrences.csv: 모든 13,074개 JASS rawcode 출현 위치(줄/함수/원문).
- 04_rawcode_ledger.csv/json: 고유 rawcode 2,371개별 출현 줄·함수·WTS 해소 원장.
- 05_damage_cc_callsites.csv: 피해/CC/감속/스턴/능력추가 후보 호출 위치. 호출은 확정이나 특정 유닛 역할 귀속은 후보입니다.
- 05_callback_registrations.csv: h5J/H5o/fWo rawcode→callback symbol→원 함수 연결. damage/CC 표의 registered_owner 컬럼 근거입니다.
- jass_function_index.csv: 원 함수명, 줄 범위, 매개변수/return, 내부 JASS callee, rawcode 참조.
- jass_call_edges.csv: 알려진 JASS 함수 사이 caller→callee 정적 간선.
- 06_jass_strings.csv: JASS 문자열 리터럴 전수.
- 06_call_statistics.csv: `call name(...)` 호출명 빈도. defined_in_jass=N에는 Warcraft native와 외부 라이브러리가 함께 포함됩니다.
- 06_hex_constants.csv: 8자리 $HEX 상수 통계.
- 06_statistics_summary.json/txt: 원본 해시와 전체 개수.
- 07_confidence_ledger.csv/txt: 확정/표시/추론/미확정 구분과 사용 금지선.
- VALIDATION_JASS.txt: 생성 후 핵심 행 수·JSON 파싱·CSV BOM 검증 결과.

공통 컬럼 의미
- rawcode: Warcraft FourCC를 latin-1 4문자로 복원한 값.
- hex: 소스의 $XXXXXXXX 표현.
- source/source_lines/line: 1부터 시작하는 원본 줄 번호.
- confidence:
  · 확정 = 실행 배열/분기/대입/호출에서 직접 확인
  · 표시 = WTS 또는 UI 문구에만 존재
  · 표시+실행 = 문구와 실행 흔적이 모두 확인됨
  · 후보/미확정 = 의미 연결이 완전하지 않아 코치 규칙으로 하드코딩 금지

검증 원칙
- 난독화된 함수·변수는 이름을 추정 변경하지 않았습니다.
- WTS 수치와 JASS 실행 수치를 분리했습니다.
- 같은 함수에 CreateUnit/KillUnit이 있다는 이유만으로 조합식으로 단정하지 않습니다.
- 2.312[R]에는 Mj>=3, Mj>=4의 실제 트리플/콰트로 완료 코드가 있어 전역 '상위 최대2' 규칙은 사용할 수 없습니다.
"""
write_txt(HERE / "README_JASS.txt", readme)

# Deterministic integrity checks before manifest creation.
checks = []
def check(name: str, ok: bool, detail: str) -> None:
    checks.append((name, ok, detail))
    if not ok:
        raise AssertionError(f"{name}: {detail}")

check("round_rows", len(waves) == 65, f"{len(waves)} == 65")
check("boss_rows", sum(bool(r["boss_rawcode"]) for r in waves) == 8,
      f"{sum(bool(r['boss_rawcode']) for r in waves)} == 8")
check("rawcode_unique", len(ledger) == 2371, f"{len(ledger)} == 2371")
check("rawcode_occurrences", len(occurrences) == 13074, f"{len(occurrences)} == 13074")
check("wts_ui_recipes", sum(r["record_type"] == "WTS_UI_RECIPE" for r in recipes) == 150,
      f"{sum(r['record_type'] == 'WTS_UI_RECIPE' for r in recipes)} == 150")
check("wts_blocks", len(wts_blocks) == 10629, f"{len(wts_blocks)} == 10629 (STRING 0 포함)")
ui_rows = [r for r in recipes if r["record_type"] == "WTS_UI_RECIPE"]
check("object_recipe_rows", len(object_recipe_rows) == 150, f"{len(object_recipe_rows)} == 150")
check("object_ability_set", {r["ability_rawcode"] for r in ui_rows} == set(object_recipe_by_ability), "150 ability rawcodes identical")
check("object_crosscheck_all", all(r["object_crosscheck"] == "MATCHED" for r in ui_rows), "150/150 MATCHED")
material_rows = [m for r in object_recipe_rows for m in r.get("materials", [])]
check("object_material_count", len(material_rows) == 433, f"{len(material_rows)} == 433")
check("object_material_resolved", sum(bool(m.get("rawcodes")) for m in material_rows) == 432,
      f"{sum(bool(m.get('rawcodes')) for m in material_rows)} resolved / 1 unresolved")
jass_unique_recipe_candidates = [r for r in recipes if r["record_type"] in {
    "JASS_CHAT_RECIPE_COMMAND", "JASS_GREENBLOOD_TRANSFORM", "JASS_CREATE_KILL_CANDIDATE"}]
check("jass_unique_recipe_candidates", len(jass_unique_recipe_candidates) == 107, f"{len(jass_unique_recipe_candidates)} == 107")
check("jass_functions", len(func_starts) == 2691, f"{len(func_starts)} == 2691")
for p in HERE.glob("*.csv"):
    check(f"csv_bom:{p.name}", p.read_bytes().startswith(b"\xef\xbb\xbf"), "UTF-8 BOM")
for p in HERE.glob("*.json"):
    if p.name != "manifest.json":
        json.loads(p.read_text(encoding="utf-8"))
        check(f"json_parse:{p.name}", True, "valid JSON")
check("recipe_csv_json_count", len(recipes) == len(json.loads((HERE / "jass_recipe_rules.json").read_text(encoding="utf-8"))),
      f"{len(recipes)} rows")
write_txt(HERE / "VALIDATION_JASS.txt", "JASS 문서 생성 검증\n\n" + "\n".join(
    f"PASS | {name} | {detail}" for name, ok, detail in checks
) + f"\n\n총 {len(checks)}개 검사 통과, 실패 0개\n")

# Manifest is written last and excludes itself.
outputs = []
for p in sorted(HERE.iterdir()):
    if p.is_file() and p.name not in {"manifest.json"}:
        outputs.append({"file": p.name, "bytes": p.stat().st_size,
                        "lines": sum(1 for _ in p.open("r", encoding="utf-8-sig", errors="replace")),
                        "sha256": sha256(p)})
manifest = {"generator": "generate_jass_docs.py", "source_sha256": summary["source"], "outputs": outputs}
write_json(HERE / "manifest.json", manifest)
print(json.dumps({"output_files": len(outputs) + 1, **summary["counts"]}, ensure_ascii=False, indent=2))
