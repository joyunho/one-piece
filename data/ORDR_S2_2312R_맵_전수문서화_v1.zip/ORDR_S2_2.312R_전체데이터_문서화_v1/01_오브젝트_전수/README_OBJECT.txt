﻿ORDR S2 2.312[R] 오브젝트 데이터 완전판

1. 범위
war3map.w3u/w3t/w3a/w3b/w3d/w3h/w3q와 war3map.wts를 전수 파싱했습니다. 이 폴더는 object data 원장입니다. 실제 라운드·생성·조합 명령·스크립트 피해는 war3map.j 문서와 합쳐야 합니다.

2. 인코딩과 표 형식
- TSV/CSV는 Windows 메모장·Excel에서 한글이 깨지지 않도록 UTF-8 BOM으로 저장했습니다.
- JSON은 UTF-8이며 한글을 ASCII escape로 바꾸지 않았습니다.
- TSV의 fieldsJson 열은 모든 field/level/dataPointer/value를 한 행 안에서 확인하기 위한 JSON 문자열입니다. 전수 modification 표에는 modification 하나가 한 행입니다.

3. 핵심 파일
- units_1406.tsv/json: 전체 유닛 정의, 등급/폼 휴리스틱, 능력·스탯·모델·아이콘·요구·업그레이드 및 모든 fields.
- unit_modifications_44997.tsv: 유닛 modification 전수.
- abilities_1642.tsv, abilities_raw_1642.json, ability_modifications_22584.tsv: 능력 전수와 원본 필드.
- unit_ability_links_5279.tsv/json: 유닛-능력 링크.
- recipes_150.csv/json/txt: object tooltip에서 확인되는 명시적 조합식.
- items_14, upgrades_110, buffs_326, doodads_39, destructibles_12: 종류별 전수표.
- wts_strings_10629.csv/json: WTS 전수.
- trigstr_reverse_index_8751.tsv/json: WTS 문자열을 참조한 모든 object modification 역색인.
- classification_ledger_1406.tsv, classification_unresolved.tsv, CLASSIFICATION_CONFIDENCE.txt: 등급/폼 판정 원장.
- FIELD_DICTIONARY.tsv: 주요 field ID 설명.
- validation.json, VALIDATION.txt: EOF·카운트·무손실 보존 검증.

4. 무손실 원칙
JSON의 mods는 field/type/level/data/endMarker와 원본 value(TRIGSTR 포함)를 보존합니다. fields에는 resolved WTS 값도 함께 둡니다. leveled object(w3a/w3d/w3q)는 level과 dataPointer를 보존하며 나머지 형식은 null로 보존합니다.

5. 해석 주의
- 등급은 정규 필드가 아니라 이름 문자열에서 분류합니다.
- 폼은 휴리스틱이며 실제 playable 여부가 아닙니다. 소환체·분신·더미·UI가 섞여 있습니다.
- object 파일은 base rawcode의 override이므로 미기록 필드는 Warcraft 기본 데이터에서 상속됩니다.
- 툴팁 수치와 실제 JASS 실행값이 다를 수 있습니다.
- 조합식 150개는 atp1='조합' + aub1='▶'인 명시적 object 레시피입니다. 히든/상위 명령 조합은 JASS/도움말과 합쳐야 합니다.
- 이 데이터는 2.312[R] 전용이며 2.305 데이터와 혼용하면 안 됩니다.
