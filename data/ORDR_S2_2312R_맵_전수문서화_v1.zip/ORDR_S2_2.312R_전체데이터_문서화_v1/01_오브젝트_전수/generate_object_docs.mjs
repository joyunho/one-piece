import fs from 'node:fs';
import path from 'node:path';

const sourceDir = '/workspace/scratch/71bed8773174/map_analysis/extracted';
const priorDir = '/workspace/scratch/71bed8773174/map_analysis/object_agent';
const outDir = '/workspace/scratch/71bed8773174/map_analysis/full_docs/object';
fs.mkdirSync(outDir, {recursive: true});

const rawDb = JSON.parse(fs.readFileSync(path.join(priorDir, 'objects_raw.json'), 'utf8'));

const FILE_SPECS = {
  'war3map.w3u': {kind:'unit', label:'유닛', leveled:false, expected:[1,1405,44997]},
  'war3map.w3t': {kind:'item', label:'아이템', leveled:false, expected:[0,14,164]},
  'war3map.w3a': {kind:'ability', label:'능력', leveled:true, expected:[7,1635,22584]},
  'war3map.w3b': {kind:'destructible', label:'파괴 가능한 물체', leveled:false, expected:[0,12,135]},
  'war3map.w3d': {kind:'doodad', label:'장식물', leveled:true, expected:[5,34,384]},
  'war3map.w3h': {kind:'buff', label:'마법/효과', leveled:false, expected:[5,321,2008]},
  'war3map.w3q': {kind:'upgrade', label:'업그레이드', leveled:true, expected:[7,103,2220]},
};

const NAME_FIELDS = {unit:'unam', item:'unam', ability:'anam', destructible:'bnam', doodad:'dnam', buff:'fnam', upgrade:'gnam'};

function decodeWts() {
  const buffer = fs.readFileSync(path.join(sourceDir, 'war3map.wts'));
  const text = buffer.toString('utf8').replace(/^\uFEFF/, '');
  const lines = text.split(/\r?\n/);
  const entries = [];
  for (let i=0; i<lines.length; i++) {
    const m = lines[i].match(/^STRING\s+(\d+)\s*$/);
    if (!m) continue;
    const id = Number(m[1]);
    const comments = [];
    while (++i < lines.length && lines[i] !== '{') {
      if (lines[i].startsWith('//')) comments.push(lines[i].replace(/^\/\/\s?/, ''));
    }
    const value = [];
    while (++i < lines.length && lines[i] !== '}') value.push(lines[i]);
    const comment = comments.join('\n');
    const head = comments[0] ?? '';
    const categoryMatch = head.match(/^([^:]+):/);
    const rawcodeMatch = head.match(/^[^:]+:\s*([^\s(]+)/);
    const fieldMatch = head.match(/\(([A-Za-z0-9]{4})\)\)\s*$/);
    entries.push({
      id, key:`TRIGSTR_${String(id).padStart(3,'0')}`, comment,
      category:categoryMatch?.[1]?.trim() ?? '', rawcode:rawcodeMatch?.[1]?.trim() ?? '',
      field:fieldMatch?.[1] ?? '', text:value.join('\n'),
    });
  }
  return {buffer, entries, byId:new Map(entries.map(x=>[x.id,x]))};
}

const wts = decodeWts();

const trigId = value => {
  const m = typeof value === 'string' && value.match(/^TRIGSTR_(\d+)$/);
  return m ? Number(m[1]) : null;
};
const resolve = value => {
  const id = trigId(value);
  return id == null ? value : (wts.byId.get(id)?.text ?? value);
};
const cleanId = value => String(value ?? '').replace(/\0/g, '');
const strip = value => String(value ?? '').replace(/\|c[0-9a-f]{8}|\|r/gi,'').trim();
const objectRawcode = object => cleanId(object.newId) || cleanId(object.oldId);

function fieldsFor(object) {
  const out = {};
  object.mods.forEach((m,index) => {
    (out[m.field] ??= []).push({index, type:m.type, level:m.level, dataPointer:m.data, rawValue:m.value, value:resolve(m.value), endMarker:m.endMarker});
  });
  return out;
}

const rawObjects = {};
for (const [file,spec] of Object.entries(FILE_SPECS)) {
  rawObjects[spec.kind] = rawDb[file].tables.flatMap(table => table.objects.map((object,index) => ({
    sourceFile:file, table:table.kind, tableIndex:index, rawcode:objectRawcode(object), baseRawcode:cleanId(object.oldId),
    newRawcode:cleanId(object.newId), v3Header:object.v3Header, mods:object.mods.map(m=>({...m,dataPointer:m.data})),
  })));
}

function first(fields, id, fallback='') { return fields[id]?.[0]?.value ?? fallback; }
function all(fields,id) { return (fields[id] ?? []).map(x=>x.value); }

const GRADES = ['안흔함','흔함','특별','희귀','전설','히든','왜곡','변화','제한','초월','불멸','영원','세라핌','신비','랜덤전용'];
function classifyGrade(name) {
  for (const grade of GRADES) {
    const re = grade === '불멸' ? /(?:\s-\s*불멸|불멸(?:\s|$))/ : new RegExp(`\\s-\\s*${grade}(?:\\s|$)`);
    if (re.test(name)) return {grade, confidence:'high', evidence:`unam 이름의 등급 표기: ${grade}`};
  }
  return {grade:'', confidence:'unresolved', evidence:'unam에 표준 등급 표기 없음'};
}

function classifyForm(name, fields) {
  const text = `${name} ${first(fields,'utip')} ${first(fields,'utub')}`;
  const rules = [
    ['dummy',/더미|복사용|부유물|공격더미|분신|소환됨|소환된|삭풍불멸/,'이름 또는 툴팁에 더미/복사/부유물/공격더미/분신/소환형 표기'],
    ['ui_control',/\bUI\b|조합식|도움소|연구소|활성화|기능 추가|남은회수|가능횟수|라운드 제한/,'UI·상태·제어용 이름'],
    ['reward_or_box',/상자|꾸러미|물품 지원|유닛도박|선택위습|랜덤위습/,'보상·상자·도박·위습 이름'],
    ['boss_or_story',/^\[(퀘스트|스토리)\]|보스|크립|몹|옥졸수/,'보스·스토리·퀘스트 이름'],
    ['ship',/해적선|방주맥심|써니호|레드포스호|모비딕호|발라티에/,'선박 이름'],
  ];
  for (const [form,re,evidence] of rules) if (re.test(text)) return {form, confidence:'medium', evidence};
  const grade=classifyGrade(name).grade;
  if (grade) return {form:'playable_candidate', confidence:'medium', evidence:'표준 등급명은 있으나 JASS 생성/선택 경로 미검증'};
  return {form:'unresolved', confidence:'unresolved', evidence:'이름/툴팁 휴리스틱으로 폼 확정 불가'};
}

const unitRows = rawObjects.unit.map(object => {
  const fields=fieldsFor(object); const name=strip(first(fields,'unam')); const grade=classifyGrade(name); const form=classifyForm(name,fields);
  if (!grade.grade && form.form !== 'unresolved') {
    grade.grade='N/A'; grade.confidence='not_applicable'; grade.evidence=`${form.form} 폼은 로스터 등급 분류 대상이 아님`;
  }
  const abilities=String(first(fields,'uabi')).split(',').filter(Boolean);
  return {
    ...object, name, grade:grade.grade, gradeConfidence:grade.confidence, gradeEvidence:grade.evidence,
    form:form.form, formConfidence:form.confidence, formEvidence:form.evidence,
    abilities, hp:first(fields,'uhpm'), mana:first(fields,'umpm'), manaRegen:first(fields,'umpr'),
    attackBase:first(fields,'ua1b'), attackDice:first(fields,'ua1d'), attackSides:first(fields,'ua1s'),
    attackCooldown:first(fields,'ua1c'), attackRange:first(fields,'ua1r'), attackType:first(fields,'ua1t'), weaponType:first(fields,'ua1w'),
    defense:first(fields,'udef'), defenseType:first(fields,'udty'), moveSpeed:first(fields,'umvs'), moveType:first(fields,'umvt'),
    targets:first(fields,'utar'), attackTargets:first(fields,'ua1g'), unitLevel:first(fields,'ulev'),
    model:first(fields,'umdl'), icon:first(fields,'uico'), requirements:first(fields,'ureq'), upgrade:first(fields,'upgr'), fields,
  };
});

const abilityRows = rawObjects.ability.map(object => {
  const fields=fieldsFor(object); return {
    ...object, name:strip(first(fields,'anam')), suffix:strip(first(fields,'ansf')), levels:first(fields,'alev'),
    tooltip:all(fields,'atp1').map(strip), extendedTooltip:all(fields,'aub1').map(x=>strip(x)),
    cooldown:all(fields,'acdn'), range:all(fields,'aran'), area:all(fields,'aare'), duration:all(fields,'adur'),
    heroDuration:all(fields,'ahdu'), manaCost:all(fields,'amcs'), buffs:all(fields,'abuf'), requirements:all(fields,'areq'),
    targets:all(fields,'atar'), icon:first(fields,'aart'), fields,
  };
});
const abilityById=new Map(abilityRows.map(x=>[x.rawcode,x]));
const unitByFullName = new Map();
for (const u of unitRows) (unitByFullName.get(u.name) ?? unitByFullName.set(u.name,[]).get(u.name)).push(u.rawcode);

const unitAbilityLinks=[];
for (const unit of unitRows) unit.abilities.forEach((abilityRawcode,slot) => {
  const ability=abilityById.get(abilityRawcode);
  unitAbilityLinks.push({unitRawcode:unit.rawcode,unitName:unit.name,unitGrade:unit.grade,slot:slot+1,abilityRawcode,
    abilityName:ability?.name ?? '',definedInMap:Boolean(ability),sourceFile:'war3map.w3u',sourceField:'uabi'});
});

function parseQuantity(text) {
  const patterns=[/\(\s*[xX×]\s*(\d+)\s*\)/,/\b[xX×]\s*(\d+)\b/,/\b(\d+)\s*기\b/];
  for (const re of patterns) { const m=text.match(re); if(m) return Number(m[1]); }
  return 1;
}
function materialName(text) {
  return text.replace(/\(\s*[xX×]\s*\d+\s*\)/g,'').replace(/\b[xX×]\s*\d+\b/g,'').replace(/\d+\s*기/g,'')
    .replace(/\s*\(다른 랜덤전용 유닛에 Z 사용\)\s*/g,' ').trim();
}
function gradeFromText(text) { return GRADES.find(g=>new RegExp(`-\\s*${g}(?:\\s|$)`).test(text)) ?? ''; }
function matchRawcodes(name) { return unitByFullName.get(name) ?? []; }

const recipes=[];
for (const a of abilityRows) {
  const tip=a.tooltip.join('\n'), body=a.extendedTooltip.find(x=>x.startsWith('▶'));
  if (!body || !/^조합/.test(tip)) continue;
  const lines=body.split('\n').map(x=>x.trim()).filter(Boolean);
  const target=lines.shift().replace(/^▶\s*/,'').trim();
  const materials=[]; const items=[]; const otherRequirements=[]; let wood=0,gold=0,tokens=0,roundMin=null,roundMax=null;
  for (const line of lines) {
    let m;
    if ((m=line.match(/([\d,]+)\s*골드/))) { gold=Number(m[1].replaceAll(',','')); continue; }
    if ((m=line.match(/목재\s*([\d,]+)/)) || (m=line.match(/([\d,]+)\s*목재/))) { wood=Number(m[1].replaceAll(',','')); continue; }
    if ((m=line.match(/행운의\s*토큰\s*(\d+)\s*개?/))) { tokens=Number(m[1]); continue; }
    if ((m=line.match(/아이템\s*:\s*(.+)/))) { items.push(m[1].trim()); continue; }
    if ((m=line.match(/(\d+)\s*라운드.*?까지/))) { roundMax=Number(m[1]); continue; }
    if ((m=line.match(/(\d+)\s*라운드.*?부터/))) { roundMin=Number(m[1]); continue; }
    if (/특성포인트/.test(line)) { otherRequirements.push(line); continue; }
    const quantity=parseQuantity(line), name=materialName(line);
    materials.push({name,grade:gradeFromText(name),quantity,rawcodes:matchRawcodes(name)});
  }
  const merged=new Map();
  for(const m of materials){const key=m.name; if(merged.has(key)) merged.get(key).quantity+=m.quantity; else merged.set(key,{...m});}
  recipes.push({recipeIndex:recipes.length+1,abilityRawcode:a.rawcode,abilityName:a.name,target,targetGrade:gradeFromText(target),
    targetRawcodes:matchRawcodes(target),materials:[...merged.values()],wood,gold,items,otherRequirements,tokens,roundMin,roundMax,
    hotkey:tip.match(/\(([A-Z])\)/)?.[1]??'',originalText:body,evidence:{sourceFile:'war3map.w3a',tipField:'atp1',bodyField:'aub1',abilityRawcode:a.rawcode}});
}
const unresolvedRecipeMaterials=recipes.flatMap(r=>r.materials.filter(m=>m.rawcodes.length===0).map(m=>({recipeIndex:r.recipeIndex,abilityRawcode:r.abilityRawcode,target:r.target,material:m.name,quantity:m.quantity,reason:'unit unam 완전일치 rawcode 없음'})));

function genericRows(kind) {
  return rawObjects[kind].map(object=>{const fields=fieldsFor(object);return {...object,name:strip(first(fields,NAME_FIELDS[kind])),fields};});
}
const itemRows=genericRows('item'), upgradeRows=genericRows('upgrade'), buffRows=genericRows('buff'), doodadRows=genericRows('doodad'), destructibleRows=genericRows('destructible');

const reverseRefs=[];
for (const [file,spec] of Object.entries(FILE_SPECS)) {
  rawDb[file].tables.forEach(table=>table.objects.forEach((object,objectIndex)=>object.mods.forEach((m,modIndex)=>{
    const id=trigId(m.value); if(id==null) return; const entry=wts.byId.get(id);
    reverseRefs.push({trigId:id,trigKey:m.value,text:entry?.text??'',comment:entry?.comment??'',category:entry?.category??'',
      sourceFile:file,objectKind:spec.kind,table:table.kind,objectIndex,objectRawcode:objectRawcode(object),baseRawcode:cleanId(object.oldId),
      modificationIndex:modIndex,field:m.field,type:m.type,level:m.level,dataPointer:m.data});
  })));
}

function scanEof(file,leveled) {
  const buf=fs.readFileSync(path.join(sourceDir,file)); let off=0;
  const i32=()=>{const x=buf.readInt32LE(off);off+=4;return x}; const id4=()=>{off+=4};
  const cstr=()=>{const end=buf.indexOf(0,off);if(end<0)throw Error(`${file} unterminated string`);off=end+1};
  const version=i32(), counts=[], modifications=[];
  for(let ti=0;ti<2;ti++){const count=i32();counts.push(count);let mc=0;for(let oi=0;oi<count;oi++){
    id4();id4();if(version>=3){i32();i32();}const n=i32();mc+=n;
    for(let mi=0;mi<n;mi++){id4();const type=i32();if(leveled){i32();i32();}if(type===0||type===1||type===2)off+=4;else if(type===3)cstr();else throw Error(`${file} invalid type ${type}`);id4();}
  }modifications.push(mc);}
  return {file,bytes:buf.length,parsedBytes:off,eofExact:off===buf.length,version,original:counts[0],custom:counts[1],modifications:modifications.reduce((a,b)=>a+b,0)};
}

const eofChecks=Object.entries(FILE_SPECS).map(([file,s])=>scanEof(file,s.leveled));
const preservation=[];
for(const [file,spec] of Object.entries(FILE_SPECS)){
  const objects=rawDb[file].tables.flatMap(t=>t.objects), mods=objects.flatMap(o=>o.mods);
  preservation.push({file,objects:objects.length,modifications:mods.length,
    everyHasType:mods.every(m=>Number.isInteger(m.type)),everyHasLevel:spec.leveled?mods.every(m=>Number.isInteger(m.level)):mods.every(m=>m.level===null),
    everyHasDataPointer:spec.leveled?mods.every(m=>Number.isInteger(m.data)):mods.every(m=>m.data===null),everyHasValue:mods.every(m=>Object.hasOwn(m,'value')),
    everyHasEndMarker:mods.every(m=>typeof m.endMarker==='string'&&Buffer.byteLength(m.endMarker,'latin1')===4),
    typeCounts:Object.fromEntries([...mods.reduce((map,m)=>map.set(m.type,(map.get(m.type)||0)+1),new Map()).entries()].sort())});
}

const gradeCounts=Object.fromEntries(GRADES.map(g=>[g,unitRows.filter(u=>u.grade===g).length]));
const formCounts=Object.fromEntries([...unitRows.reduce((m,u)=>m.set(u.form,(m.get(u.form)||0)+1),new Map()).entries()].sort());
const unresolved=unitRows.filter(u=>u.gradeConfidence==='unresolved'||u.formConfidence==='unresolved').map(u=>({rawcode:u.rawcode,name:u.name,grade:u.grade,gradeConfidence:u.gradeConfidence,form:u.form,formConfidence:u.formConfidence,reason:[u.gradeEvidence,u.formEvidence].join(' / ')}));

const validation={generatedAt:new Date().toISOString(),sourceMap:'ORDR_S2_2.312[R].w3x',eofChecks,
 expectedCounts:Object.fromEntries(Object.entries(FILE_SPECS).map(([f,s])=>[f,{expectedOriginal:s.expected[0],expectedCustom:s.expected[1],expectedModifications:s.expected[2]}])),
 preservation,wts:{bytes:wts.buffer.length,strings:wts.entries.length,maxId:Math.max(...wts.entries.map(x=>x.id)),replacementCharacters:wts.buffer.toString('utf8').split('\uFFFD').length-1,
 trigReferences:reverseRefs.length,unresolvedTrigReferences:reverseRefs.filter(x=>!wts.byId.has(x.trigId)).length},
 documented:{units:unitRows.length,abilities:abilityRows.length,unitAbilityLinks:unitAbilityLinks.length,recipes:recipes.length,items:itemRows.length,upgrades:upgradeRows.length,buffs:buffRows.length,doodads:doodadRows.length,destructibles:destructibleRows.length},
 gradeCounts,formCounts,unresolvedClassifications:unresolved.length,
 recipeResolution:{targets:recipes.length,targetsMatched:recipes.filter(r=>r.targetRawcodes.length>0).length,
 materials:recipes.flatMap(r=>r.materials).length,materialsMatched:recipes.flatMap(r=>r.materials).filter(m=>m.rawcodes.length>0).length,
 unresolvedMaterialOccurrences:unresolvedRecipeMaterials.length,
 targetGradeCounts:Object.fromEntries([...recipes.reduce((m,r)=>m.set(r.targetGrade,(m.get(r.targetGrade)||0)+1),new Map()).entries()].sort()),
 withWood:recipes.filter(r=>r.wood>0).length,withGold:recipes.filter(r=>r.gold>0).length,withItems:recipes.filter(r=>r.items.length>0).length,
 withTokens:recipes.filter(r=>r.tokens>0).length,withRoundMin:recipes.filter(r=>r.roundMin!=null).length,withRoundMax:recipes.filter(r=>r.roundMax!=null).length,
 withOtherRequirements:recipes.filter(r=>r.otherRequirements.length>0).length}};

function writeJson(file,value){fs.writeFileSync(path.join(outDir,file),JSON.stringify(value,null,2)+'\n','utf8');}
function escTsv(x){return String(x??'').replace(/[\t\r\n]+/g,' / ')}
function writeTsv(file,headers,rows){fs.writeFileSync(path.join(outDir,file),'\uFEFF'+[headers,...rows].map(row=>row.map(escTsv).join('\t')).join('\n')+'\n','utf8');}
function escCsv(x){const s=String(x??'');return /[",\r\n]/.test(s)?`"${s.replaceAll('"','""')}"`:s}
function writeCsv(file,headers,rows){fs.writeFileSync(path.join(outDir,file),'\uFEFF'+[headers,...rows].map(row=>row.map(escCsv).join(',')).join('\r\n')+'\r\n','utf8');}

const unitHeaders=['rawcode','baseRawcode','newRawcode','table','name','grade','gradeConfidence','form','formConfidence','abilities','abilityNames','hp','mana','manaRegen','attackBase','attackDice','attackSides','attackCooldown','attackRange','attackType','weaponType','defense','defenseType','moveSpeed','moveType','targets','attackTargets','unitLevel','model','icon','requirements','upgrade','modificationCount','fieldsJson'];
writeTsv('units_1406.tsv',unitHeaders,unitRows.map(u=>[u.rawcode,u.baseRawcode,u.newRawcode,u.table,u.name,u.grade,u.gradeConfidence,u.form,u.formConfidence,u.abilities.join(','),u.abilities.map(id=>abilityById.get(id)?.name||'').join(','),u.hp,u.mana,u.manaRegen,u.attackBase,u.attackDice,u.attackSides,u.attackCooldown,u.attackRange,u.attackType,u.weaponType,u.defense,u.defenseType,u.moveSpeed,u.moveType,u.targets,u.attackTargets,u.unitLevel,u.model,u.icon,u.requirements,u.upgrade,u.mods.length,JSON.stringify(u.fields)]));
writeJson('units_1406.json',unitRows);
writeTsv('unit_modifications_44997.tsv',['objectRawcode','baseRawcode','table','modificationIndex','field','type','level','dataPointer','rawValue','resolvedValue','endMarkerHex'],unitRows.flatMap(u=>u.mods.map((m,i)=>[u.rawcode,u.baseRawcode,u.table,i,m.field,m.type,m.level,m.data,m.value,resolve(m.value),Buffer.from(m.endMarker,'latin1').toString('hex')])));

const abilityHeaders=['rawcode','baseRawcode','newRawcode','table','name','suffix','levels','tooltip','extendedTooltip','cooldown','range','area','duration','heroDuration','manaCost','buffs','requirements','targets','icon','modificationCount','fieldsJson'];
writeTsv('abilities_1642.tsv',abilityHeaders,abilityRows.map(a=>[a.rawcode,a.baseRawcode,a.newRawcode,a.table,a.name,a.suffix,a.levels,a.tooltip.join(' | '),a.extendedTooltip.join(' | '),JSON.stringify(a.cooldown),JSON.stringify(a.range),JSON.stringify(a.area),JSON.stringify(a.duration),JSON.stringify(a.heroDuration),JSON.stringify(a.manaCost),JSON.stringify(a.buffs),JSON.stringify(a.requirements),JSON.stringify(a.targets),a.icon,a.mods.length,JSON.stringify(a.fields)]));
writeJson('abilities_raw_1642.json',abilityRows);
writeTsv('ability_modifications_22584.tsv',['objectRawcode','baseRawcode','table','modificationIndex','field','type','level','dataPointer','rawValue','resolvedValue','endMarkerHex'],abilityRows.flatMap(a=>a.mods.map((m,i)=>[a.rawcode,a.baseRawcode,a.table,i,m.field,m.type,m.level,m.data,m.value,resolve(m.value),Buffer.from(m.endMarker,'latin1').toString('hex')])));

writeTsv('unit_ability_links_5279.tsv',['unitRawcode','unitName','unitGrade','slot','abilityRawcode','abilityName','definedInMap','sourceFile','sourceField'],unitAbilityLinks.map(x=>Object.values(x)));
writeJson('unit_ability_links_5279.json',unitAbilityLinks);

const recipeHeaders=['recipeIndex','abilityRawcode','abilityName','target','targetGrade','targetRawcodes','materials','wood','gold','items','otherRequirements','tokens','roundMin','roundMax','hotkey','originalText','evidence'];
const recipeRows=recipes.map(r=>[r.recipeIndex,r.abilityRawcode,r.abilityName,r.target,r.targetGrade,r.targetRawcodes.join('|'),r.materials.map(m=>`${m.name} x${m.quantity}${m.rawcodes.length?` [${m.rawcodes.join('|')}]`:''}`).join(' ; '),r.wood,r.gold,r.items.join(' ; '),r.otherRequirements.join(' ; '),r.tokens,r.roundMin,r.roundMax,r.hotkey,r.originalText,`${r.evidence.sourceFile}:${r.evidence.abilityRawcode}:${r.evidence.tipField}+${r.evidence.bodyField}`]);
writeCsv('recipes_150.csv',recipeHeaders,recipeRows);writeJson('recipes_150.json',recipes);
fs.writeFileSync(path.join(outDir,'recipes_150.txt'),'\uFEFF'+recipes.map(r=>`[${r.recipeIndex}] ${r.target} (${r.abilityRawcode})\n등급: ${r.targetGrade}\n재료: ${r.materials.map(m=>`${m.name} x${m.quantity}`).join(', ')||'없음'}\n비용: 목재 ${r.wood}, 골드 ${r.gold}, 토큰 ${r.tokens}${r.items.length?`, 아이템 ${r.items.join(', ')}`:''}${r.otherRequirements.length?`, 기타조건 ${r.otherRequirements.join(', ')}`:''}\n라운드: ${r.roundMin??'-'} ~ ${r.roundMax??'-'}\n근거: war3map.w3a / atp1+aub1 / ${r.abilityRawcode}\n원문:\n${r.originalText}\n`).join('\n'),'utf8');
writeTsv('recipe_unresolved_materials.tsv',['recipeIndex','abilityRawcode','target','material','quantity','reason'],unresolvedRecipeMaterials.map(x=>Object.values(x)));
writeJson('recipe_unresolved_materials.json',unresolvedRecipeMaterials);

function writeGeneric(base,rows){writeTsv(`${base}.tsv`,['rawcode','baseRawcode','newRawcode','table','name','modificationCount','fieldsJson'],rows.map(x=>[x.rawcode,x.baseRawcode,x.newRawcode,x.table,x.name,x.mods.length,JSON.stringify(x.fields)]));writeJson(`${base}.json`,rows);}
writeGeneric('items_14',itemRows);writeGeneric('upgrades_110',upgradeRows);writeGeneric('buffs_326',buffRows);writeGeneric('doodads_39',doodadRows);writeGeneric('destructibles_12',destructibleRows);

writeCsv('wts_strings_10629.csv',['id','key','comment','category','rawcode','field','text'],wts.entries.map(x=>[x.id,x.key,x.comment,x.category,x.rawcode,x.field,x.text]));
writeJson('wts_strings_10629.json',wts.entries);
writeTsv('trigstr_reverse_index_8751.tsv',['trigId','trigKey','text','comment','category','sourceFile','objectKind','table','objectIndex','objectRawcode','baseRawcode','modificationIndex','field','type','level','dataPointer'],reverseRefs.map(x=>Object.values(x)));
writeJson('trigstr_reverse_index_8751.json',reverseRefs);

writeTsv('classification_ledger_1406.tsv',['rawcode','name','grade','gradeConfidence','gradeEvidence','form','formConfidence','formEvidence'],unitRows.map(u=>[u.rawcode,u.name,u.grade,u.gradeConfidence,u.gradeEvidence,u.form,u.formConfidence,u.formEvidence]));
writeTsv('classification_unresolved.tsv',['rawcode','name','grade','gradeConfidence','form','formConfidence','reason'],unresolved.map(x=>Object.values(x)));
fs.writeFileSync(path.join(outDir,'CLASSIFICATION_CONFIDENCE.txt'),'\uFEFF'+`등급 분류\n- high: unam의 표준 ' - 등급' 문자열과 일치.\n- not_applicable: 더미/UI/보상/보스 등 비로스터 폼이라 등급 분류 대상이 아님.\n- unresolved: 정규 등급 표기가 없음.\n\n폼 분류\n- medium: 이름/툴팁 휴리스틱으로 playable 후보, 선박, 더미/소환, UI, 보상, 보스/스토리를 표시.\n- unresolved: object data만으로 폼을 판단하지 못함.\n\n주의\n- playable_candidate는 실제 선택 가능 확정값이 아닙니다. war3map.j의 생성·삭제·조합·소환 경로와 교차검증해야 합니다.\n- 소환체/분신/공격더미가 표준 등급명을 포함할 수 있어 등급 수와 실제 로스터 수가 다릅니다.\n\n등급 집계(raw definition):\n${Object.entries(gradeCounts).map(([k,v])=>`${k}: ${v}`).join('\n')}\n\n폼 집계:\n${Object.entries(formCounts).map(([k,v])=>`${k}: ${v}`).join('\n')}\n\n미해소 원장: classification_unresolved.tsv (${unresolved.length}개)\n`,'utf8');

const FIELD_DICTIONARY=[
['unam','유닛/아이템 이름'],['uabi','유닛 능력 rawcode 목록'],['uhpm','최대 체력'],['umpm','최대 마나'],['umpr','마나 회복'],['ua1b','공격1 기본 피해'],['ua1d','공격1 주사위 수'],['ua1s','공격1 주사위 면'],['ua1c','공격1 주기'],['ua1r','공격1 사거리'],['ua1t','공격1 타입'],['ua1w','공격1 무기 타입'],['udef','기본 방어'],['udty','방어 타입'],['umvs','이동속도'],['umvt','이동 타입'],['utar','대상 허용'],['ua1g','공격 대상 허용'],['ulev','유닛 레벨'],['umdl','모델'],['uico','아이콘'],['ureq','요구 업그레이드'],['upgr','적용 업그레이드'],
['anam','능력 이름'],['atp1','능력 일반 툴팁'],['aub1','능력 확장 툴팁'],['alev','능력 레벨 수'],['acdn','쿨다운'],['aran','사거리'],['aare','범위'],['adur','일반 지속시간'],['ahdu','영웅 지속시간'],['amcs','마나 비용'],['abuf','버프 rawcode'],['areq','요구 업그레이드'],['atar','대상 허용'],['aart','아이콘'],
['gnam','업그레이드 이름'],['glvl','업그레이드 레벨 수'],['gef1/gef2','업그레이드 효과 종류'],['gba1/gba2','효과 기본값'],['gmo1/gmo2','레벨별 증분'],['greq','업그레이드 요구'],['fnam','버프/효과 이름'],['ftip/fube','버프 툴팁'],['bnam','파괴물 이름'],['dnam','장식물 이름']];
writeTsv('FIELD_DICTIONARY.tsv',['fieldId','meaning'],FIELD_DICTIONARY);

writeJson('validation.json',validation);
fs.writeFileSync(path.join(outDir,'VALIDATION.txt'),'\uFEFF'+`검증 결과\n생성시각: ${validation.generatedAt}\n\nEOF 검증\n${eofChecks.map(x=>`${x.file}: ${x.parsedBytes}/${x.bytes}, EOF=${x.eofExact}, objects=${x.original+x.custom}, modifications=${x.modifications}`).join('\n')}\n\n필드 무손실 보존\n${preservation.map(x=>`${x.file}: mods=${x.modifications}, type=${x.everyHasType}, level=${x.everyHasLevel}, dataPointer=${x.everyHasDataPointer}, value=${x.everyHasValue}, endMarker=${x.everyHasEndMarker}, typeCounts=${JSON.stringify(x.typeCounts)}`).join('\n')}\n\nWTS: ${validation.wts.strings}개, TRIGSTR 참조 ${validation.wts.trigReferences}개, 미해소 ${validation.wts.unresolvedTrigReferences}개, UTF-8 replacement ${validation.wts.replacementCharacters}개(주석 헤더)\n\n조합식 연결: ${JSON.stringify(validation.recipeResolution)}\n\n문서 행 대상: ${JSON.stringify(validation.documented)}\n`,'utf8');

const readme=`ORDR S2 2.312[R] 오브젝트 데이터 완전판\n\n1. 범위\nwar3map.w3u/w3t/w3a/w3b/w3d/w3h/w3q와 war3map.wts를 전수 파싱했습니다. 이 폴더는 object data 원장입니다. 실제 라운드·생성·조합 명령·스크립트 피해는 war3map.j 문서와 합쳐야 합니다.\n\n2. 인코딩과 표 형식\n- TSV/CSV는 Windows 메모장·Excel에서 한글이 깨지지 않도록 UTF-8 BOM으로 저장했습니다.\n- JSON은 UTF-8이며 한글을 ASCII escape로 바꾸지 않았습니다.\n- TSV의 fieldsJson 열은 모든 field/level/dataPointer/value를 한 행 안에서 확인하기 위한 JSON 문자열입니다. 전수 modification 표에는 modification 하나가 한 행입니다.\n\n3. 핵심 파일\n- units_1406.tsv/json: 전체 유닛 정의, 등급/폼 휴리스틱, 능력·스탯·모델·아이콘·요구·업그레이드 및 모든 fields.\n- unit_modifications_44997.tsv: 유닛 modification 전수.\n- abilities_1642.tsv, abilities_raw_1642.json, ability_modifications_22584.tsv: 능력 전수와 원본 필드.\n- unit_ability_links_5279.tsv/json: 유닛-능력 링크.\n- recipes_150.csv/json/txt: object tooltip에서 확인되는 명시적 조합식.\n- items_14, upgrades_110, buffs_326, doodads_39, destructibles_12: 종류별 전수표.\n- wts_strings_10629.csv/json: WTS 전수.\n- trigstr_reverse_index_8751.tsv/json: WTS 문자열을 참조한 모든 object modification 역색인.\n- classification_ledger_1406.tsv, classification_unresolved.tsv, CLASSIFICATION_CONFIDENCE.txt: 등급/폼 판정 원장.\n- FIELD_DICTIONARY.tsv: 주요 field ID 설명.\n- validation.json, VALIDATION.txt: EOF·카운트·무손실 보존 검증.\n\n4. 무손실 원칙\nJSON의 mods는 field/type/level/data/endMarker와 원본 value(TRIGSTR 포함)를 보존합니다. fields에는 resolved WTS 값도 함께 둡니다. leveled object(w3a/w3d/w3q)는 level과 dataPointer를 보존하며 나머지 형식은 null로 보존합니다.\n\n5. 해석 주의\n- 등급은 정규 필드가 아니라 이름 문자열에서 분류합니다.\n- 폼은 휴리스틱이며 실제 playable 여부가 아닙니다. 소환체·분신·더미·UI가 섞여 있습니다.\n- object 파일은 base rawcode의 override이므로 미기록 필드는 Warcraft 기본 데이터에서 상속됩니다.\n- 툴팁 수치와 실제 JASS 실행값이 다를 수 있습니다.\n- 조합식 150개는 atp1='조합' + aub1='▶'인 명시적 object 레시피입니다. 히든/상위 명령 조합은 JASS/도움말과 합쳐야 합니다.\n- 이 데이터는 2.312[R] 전용이며 2.305 데이터와 혼용하면 안 됩니다.\n`;
fs.writeFileSync(path.join(outDir,'README_OBJECT.txt'),'\uFEFF'+readme,'utf8');

const manifestRecords={
  'units_1406.tsv':unitRows.length,'units_1406.json':unitRows.length,'unit_modifications_44997.tsv':unitRows.reduce((n,u)=>n+u.mods.length,0),
  'abilities_1642.tsv':abilityRows.length,'abilities_raw_1642.json':abilityRows.length,'ability_modifications_22584.tsv':abilityRows.reduce((n,a)=>n+a.mods.length,0),
  'unit_ability_links_5279.tsv':unitAbilityLinks.length,'unit_ability_links_5279.json':unitAbilityLinks.length,
  'recipes_150.csv':recipes.length,'recipes_150.json':recipes.length,'recipes_150.txt':recipes.length,
  'recipe_unresolved_materials.tsv':unresolvedRecipeMaterials.length,'recipe_unresolved_materials.json':unresolvedRecipeMaterials.length,
  'items_14.tsv':itemRows.length,'items_14.json':itemRows.length,'upgrades_110.tsv':upgradeRows.length,'upgrades_110.json':upgradeRows.length,
  'buffs_326.tsv':buffRows.length,'buffs_326.json':buffRows.length,'doodads_39.tsv':doodadRows.length,'doodads_39.json':doodadRows.length,
  'destructibles_12.tsv':destructibleRows.length,'destructibles_12.json':destructibleRows.length,
  'wts_strings_10629.csv':wts.entries.length,'wts_strings_10629.json':wts.entries.length,
  'trigstr_reverse_index_8751.tsv':reverseRefs.length,'trigstr_reverse_index_8751.json':reverseRefs.length,
  'classification_ledger_1406.tsv':unitRows.length,'classification_unresolved.tsv':unresolved.length,
  'FIELD_DICTIONARY.tsv':FIELD_DICTIONARY.length,'CLASSIFICATION_CONFIDENCE.txt':1,'VALIDATION.txt':1,'validation.json':1,'README_OBJECT.txt':1,
  'generate_object_docs.mjs':1,
};
const manifestRows=Object.entries(manifestRecords).map(([file,records])=>[file,path.extname(file).slice(1).toUpperCase(),records,fs.statSync(path.join(outDir,file)).size,
  /\.(tsv|csv|txt)$/i.test(file)?'UTF-8 BOM':/\.json$/i.test(file)?'UTF-8 JSON (no BOM)':'UTF-8 source']);
writeTsv('FILE_MANIFEST.tsv',['file','format','logicalRecords','bytes','encoding'],manifestRows);

console.log(JSON.stringify(validation,null,2));
